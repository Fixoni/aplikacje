<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="" method="POST">
        <input type="number" name="liczenie">
    </form>
    
</body>
</html>

<?php
$l=$_POST["liczenie"];

$l=$l-10;
echo $l."<br>";
$l=abs($l);
echo $l."<br>";
$l=pow($l,2);
echo $l."<br>";
$l=decoct($l);
echo $l."<br>";


?>