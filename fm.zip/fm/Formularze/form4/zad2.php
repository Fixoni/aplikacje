<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h3>Kwieciarnia</h3>
    <form action="" method="POST">
        Wybierz kwiatek:
        <select name="kwiatek" id="kwiatek">
        <?php
        $odczyt=fopen("kwiaty.txt","r");
        for($i=0;$i<7;$i++) {
            $kwiat=fgets($odczyt);
            $x=explode(" ",$kwiat);
            echo "<option value='$x[0]'>$x[0]</option>";
        }
        ?>
        </select> <br>
        <label for="ilosc">Ile sztuk:</label>
        <input type="number" name="ilosc"> <br>
        <label for="przyozdobnienie">Przyozdobnienie</label>
        <input type="checkbox" name="przyozdobnienie" id="przyozdobnienie">
        <button type="Submit">Zatwierdź</button>
    </form>
    <?php
    if(empty($_POST['kwiatek'])==true || empty($_POST['ilosc'])==true) {
        echo "<span style='color:red'>Brak danych!</span>";
    } else {
        $kwiatek=$_POST['kwiatek'];
        $ilosc=$_POST['ilosc'];
        $przyozdobnienie=$_POST['przyozdobnienie'];
        $cena=0;
        if($przyozdobnienie==true) {
            $cena=$cena+20;
        }
        
        echo "Zakupiono ".$x[0]." o ilości sztuk ".$ilosc." o kolorze ".$x[1]." za ".$cena."zł";
    }
    
    ?>
</body>
</html>