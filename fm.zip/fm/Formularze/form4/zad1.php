<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
<form method="POST" action="">
Podaj nazwisko <input type="text" name="nazwisko"><br>
Zawód który wykonujesz
<select name='zawod' id=''>
<?php
$p=fopen("dane.txt","r");
for($i=0;$i<8;$i++) {
    $zawod=fgets($p);
   echo "<option value='$zawod'>$zawod</option>";
}

?>
   </select> <br>
   <button type="Submit">Zatwierdź</button>
</form>
<br>
<?php
/*
if(isset($_POST['nazwisko']) || isset($_POST['zawod'])) {
    echo "Brak podanych danych";
}
*/
$nazwisko=$_POST['nazwisko'];
$zawod2=$_POST['zawod'];
echo $nazwisko." pracujesz jako: ".$zawod;

$zapis=fopen("wyniki.txt","a");
fwrite($zapis,"Nazwisko: $nazwisko pracujesz jako: $zawod2");
?>

</body>
</html>