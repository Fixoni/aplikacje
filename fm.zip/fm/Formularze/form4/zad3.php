<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h3>Dane nauczyciela</h3>
    <form action="" method="POST">
    Nazwisko: <input type="text" name="nazwisko"> <br>
    Nauczane przedmioty: <br>
    <select name="przedmiot[]" id="przedmiot" multiple>
    <?php
$p=fopen("przedmioty.txt","r");
for($i=0;$i<8;$i++) {
    $przedmiot=fgets($p);
   echo "<option value='$przedmiot'>$przedmiot</option>";
}
?>
</select> <br>
<label for="stopien">stopien awansu: </label>
stażysta <input type="radio" name="stażysta">
mianowany <input type="radio" name="mianowany">
dyplomowany <input type="radio" name="dyplomowany">

staż pracy <input type="number" name="staż">

<button type="submit">Zatwierdź</button>
</form>
    
<?php


?>
</body>
</html>