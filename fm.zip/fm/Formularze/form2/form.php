<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>

<form action="" method="POST">
    <label>Szerokość pokoju:<input type="number" name="szerokosc"></label><br>
    <label>Wysokość pokoju:<input type="number" name="wysokosc"></label><br>
    <label>Długość pokoju:<input type="number" name="dlugosc"></label><br>

    <label>Rodzaj pędzla:
    Wąski <input type="radio" name="pedzel">
    Szeroki <input type="radio" name="pedzel"></label>

    <br> Rodzaj farby: <br>
    <select name="farba">
        <option value="lateksowa">Lateksowa</option>
        <option value="akrylowa">Akrylowa</option>
        <option value="winylowa">Winylowa</option>
    </select>
    <br>
    <button type="submit">Zatwierdź</button>

</form>
<?php
error_reporting(0); 
$sz=$_POST["szerokosc"];
$w=$_POST["wysokosc"];
$d=$_POST["dlugosc"];
$ped=$_POST["pedzel"]

$p=$sz*$d+2*$sz*$w+2*$d*$w;
echo $p." m^2";

$kfa=25;
$kfw=30;
$kfl=35;

$s=0;
switch ($value) {
    case 'akrylowa':
        $kfa;
        $s=$p*$kfa;
        break;
    case 'winylowa':
        $kfw;
        $s=$p*$kfw;
    case 'lateksowa';
        $kfl;
        $s=$p*$kfl;
    default:
        echo "Wybierz poprawna opcje!!";
        break;
}
switch ($variable) {
    case 'value':
        # code...
        break;
    
    default:
        # code...
        break;
}

?>

</body>
</html>