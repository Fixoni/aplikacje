<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formularz</title>
</head>
<body>
<form action="" method="POST">
    Podaj nazwisko 
    <br>
    <input type="text" name="nazwisko">
    <br>
    Podaj wiek
    <br>
    <input type="number" name="wiek">
    <br>
    <button type="submit">Wyślij</button>

</form>    

<?php

$n = $_POST["nazwisko"];
$w = $_POST["wiek"];
if($w<=18) {
    echo $n." witaj na mojej stronie. Masz lat ".$w." jesteś niepełnoletni.";
} else {
    echo $n." witaj na mojej stronie. Masz lat ".$w." jesteś pełnoletni.";
}

?>

</body>
</html>