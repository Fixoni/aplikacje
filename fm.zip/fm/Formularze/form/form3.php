<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="" method="POST">
    Podaj nazwisko
    <br>
    <input type="text" name="nazwisko">
    Miejsce urodzenia
    <br>
    <input type="text" name="miejsce_uro">
    <br>
    <button type="submit">Potwierdź</button>
    </form>
<?php

if(empty($_POST["nazwisko"])==true || empty($_POST["miejsce_uro"])==true) {
        echo "<span style='color: red;'>Uzupełnij dane!!!</span>";
} else {
    $naz=$_POST["nazwisko"];
    $miejsce_uro=$_POST["miejsce_uro"];
    echo "Twoje nazwisko: ".$naz.". Twoje miejsce urodzenia: ".$miejsce_uro;
}


?>

</body>
</html>