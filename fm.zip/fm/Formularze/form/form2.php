<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="" method="POST">
        <h2>Obliaczanie kosztu ogrodzenia</h2>
        Szerokość:
        <input type="number" name="szerokosc">
        <br>
        Długość:
        <input type="number" name="dlugosc">
        <br>
        Materiał: 
        Drewno <input type="radio" name="material">
        Metal <input type="radio" name="material"> 
        <br>
        Firma <input type="checkbox" name="firma"> 
        <br>
        <button type="submit">Oblicz</button>
        <br><br>
    </form>
<?php
error_reporting(0);
$szerokosc = $_POST["szerokosc"];
$dlugosc = $_POST["dlugosc"];
$material = $_POST["material"];
$firma = $_POST["firma"];
echo "Szerokość wynosi: ".$szerokosc."<br>";
echo "Długość wynosi: ".$dlugosc."<br>";
$suma = $szerokosc*$dlugosc;
echo "Potrzeba ".$suma." metrów <br>";
echo "Materiał: ".$material;
$cena = 0;
if($fimra==true)
{
    echo "Firma: TAK";
    if($material=="Metal") {
       $cena=$dlugosc*400;
    } else {
        $cena=$dlugosc*200;
    }
}
    else {
        echo "Firma: NIE";
        if($material=="Drewno") {
           $cena=$dlugosc*300;
        } else {
            $cena=$dlugosc*250;
        }
    }
    echo "<br>";
echo "Cena wynosi: ".$cena." zl";

/*
metal za metr 300 zl
firma za metr 400 zl
drewno za metr 250 zl
firma za metr 200 zl
*/
?>
</body>
</html>