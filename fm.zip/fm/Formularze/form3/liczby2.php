<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body> 
    <form method="POST">
        <label>A1</label>
        <input type="number" name="a" min="0" step="0.1"> 
        <br>
        <label>Liczba wyrazów N:</label>
        <input type="number" name="n">
        <br>
        <label>Interwał: </label>
        <select name="interwal" id="interwal">
            <option value="geo">Geometryczne</option>
            <option value="art">Arytmetyczne</option>
        </select>
        <br>
        <button type="submit">Oblicz</button>
    </form>
</body>
</html>

<?php
$a=$_POST['a'];
$r=$_POST['r'];
$n=$_POST['n'];

function potega($a,$n) {
    for($i=1;$i<=$n;$i++) {
        $pot=$pot*$a;
    }
}
return $pot;

?>