<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body> 
    <form method="POST">
    <h2>Oblicz, ile litrów musisz zatankować</h2>
    <br>
    Dystans do przejechania w km <br>
    <input type="number" name="km">
    <br>
    Spalanie samochodu w 1/100km
    <br>
    <input type="number" name="spalanie" min="0" step="0.1">
    <br> Wybierz paliwo: 
    Benzyna <input type="radio" name="tankowanie"> Olej napędowy <input type="radio" name="tankowanie"> 
    <br>
    <button type="submit">Oblicz</button>
    
    </form>
</body>
</html>

<?php
$km = $_POST['km'];
$spalanie = $_POST['spalanie'];
$tankowanie = $_POST['tankowanie'];
$spalanie=($spalanie/100)*$km;
echo "Potrzebujesz ".$spalanie." litrów paliwa.";
$koszt=$spalanie;
echo "<br>";
    if($tankowanie == "Benzyna") {
        $koszt=$koszt*4;
        echo "Koszt: ".$koszt." zł <br>";
    } else if("Olej napędowy"){
        $koszt=$koszt*3.8;
        echo "Koszt: ".$koszt." zł <br>";
    }




?>