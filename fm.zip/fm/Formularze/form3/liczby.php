<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body> 
    <form method="POST">
        <label>A1</label>
        <input type="number" name="a">
        <br>
        <label>R</label>
        <input type="number" name="r">
        <br>
        <label>N</label>
        <input type="number" name="n">
        <br>
        <button type="submit">Oblicz</button>
    </form>
</body>
</html>

<?php
$a=$_POST['a'];
$r=$_POST['r'];
$n=$_POST['n'];

for($i=0;$i<$n;$i++) {
    echo "$a, ";
    $a=$a+$r;
}
?>