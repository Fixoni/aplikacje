
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        body{
            text-align:center ;
        }
    </style>
</head>
<body>
<?php
//szerokość długośc wysokość
//rodzaj pędzel wąski/szeroki
//lista rozwijalna rodzaj farby lateksowa=35zl/akrylowe=25zl/winylowa=30zl m2
//przycisk konfidenta
//powierzchnia  do pamalowania $powierzchnia  m2
//koszt farby $koszt zł
//czas malowania wąski 15min/szeroki 5min na m2 zamiana na godziny czas malowania $czas
?>
    <h2>Kwestionariusz osobowy</h2>
    <form action="zad12.php" method="POST">
        <input type="text" name="imie" id="1" placeholder="Podaj imie">
        <br><br>
        <input type="text" name="nazwisko" id="2" placeholder="Podaj nazwisko">
        <br><br>
        <label for="plec">płeć </label>
        <br>
        <label for="plec">Kobieta</label>
        <input type="radio" name="plec" value="kobieta"><br>
        <label for="plec">Mężczyzna</label>
        <input type="radio" name="plec" value="mężczyzna">
        <br><br>
        <label for="hobby">Jakich języków obcych sie uczysz?</label>
 <select id="hobby" name="hobby[]" multiple>
        <option value="granie">granie na komputerze</option>
        <option value="plywanie">plywanie</option>
        <option value="słuchanie">słuchanie muzyki</option>
        <option value="czytanie">czytanie</option>
        <option value="programowanie">programowanie</option>
 </select>
        <br><br>
        <select name="osoby" id="4">
            <option value="<5">mniej niż 5 tysięcy</option>
            <option value="20>5">od 5 do 20 tysięcy</option>
            <option value=">20">powyżej 20 tysięcy</option>
        </select><br>
        <input type="submit" value="wyślij">

    </form>
    <?php
     if (empty($_POST['imie']) || empty($_POST['nazwisko']) || empty($_POST['plec']) || empty($_POST['hobby']))
     {
       echo "Podaj dane";
     }
     else{

     

        $imie = $_POST['imie'];
        $nazw = $_POST['nazwisko'];
        $plec = $_POST['plec'];
        $hobby = $_POST['hobby'];
        $osoby = $_POST['osoby'];
        $s = 0;

        echo "$imie $nazw twoja plec to : $plec<br> twoje hobby to: ";
        for ($i = 0; $i < sizeof($hobby); $i++) {
            echo $hobby[$i].", ";
            $s++;
        }
        echo"wybrałeś $s opcji";
        switch ($osoby) {
            case '<5':
                echo "<br>Mieszkasz w mieście które ma poniżej 5000 mieszkańców";
                break;

                case '20>5':
                    echo "<br>Mieszkasz w mieście które ma powyżej 5000 mieszkańców a mniej niż 20000 mieszczańców";
                    break;

                    case '>20':
                        echo "<br>Mieszkasz w mieście które ma powyżej 20000 mieszkańców";
                        break;
            
            default:
                # code...
                break;
        }
    }
       


    ?>

</body>
</html>