<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Powtórka do sprawdzianu</title>
</head>
<body>
    <h2> Oblicz, ile litrów musisz zatankować </h2>
    <form action="" method="POST">
        <label for="">dystans do przejechania w km</label>
        <input type="number" name="dystans">
        <br>
        <label for="">spalanie samochodu w 1/100km</label>
        <input type="number" name="spalanie" min="0" step="0.1">
        <br>
        <label for="">Wybierz rodzaj paliwa</label><br>
        <input type="radio" name="rodzaj" value="benzyna">Benzyna <br>
        <input type="radio" name="rodzaj" value="olej">Olej napędowy<br>
        <button type="submit">OBLICZ</button>
    </form>
    <?php
    $wynik = 0;
    $cena = 0;
$dystans = $_POST['dystans'];
$spalanie = $_POST['spalanie'];
$rodzaj = $_POST['rodzaj'];

echo " Dystans => $dystans km <br> Spalanie => $spalanie<br> Rodzaj => $rodzaj <br>"; 
 $wynik = ($spalanie/100)*$dystans;
if($rodzaj=="benzyna"){
    $cena=$wynik*4;
}else{
    $cena=$wynik*3.8;
}
echo "Potrzebujesz $wynik litrów paliwa, Koszt wynosi $cena zł";

?>
    
</body>
</html>