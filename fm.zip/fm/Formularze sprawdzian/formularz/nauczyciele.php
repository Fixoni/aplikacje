<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="nauczyciele.php" method="POST">
        <label for="">Nazwisko</label>
        <input type="text" name="nazwisko" id="nazwisko">
        <br><br>
        <label for="">nauczane przedmioty</label>
        <select name="przedmiot[]" id="przedmiot" multiple> <!-- Lista wielokrotnego wyboru -->
        <?php
        $plik = fopen('przedmioty.txt','r'); //otwieranie pliku z przedmiotami
        for($i=0;$i<6;$i++){ //wypisanie nazwy przedmiotów w formularzu
            $p = fgets($plik); //pobranie z pliku danych
            echo"<option>$p</option>"; //wyswietlanie   w opcji
        }
        ?>
        </select>
        <br><br>
        <label for="">stopień zaawansowania</label>
        <input type="radio" name="stopien" value="starzysta">starzysta
        <input type="radio" name="stopien" value="mianowany">mianowany
        <input type="radio" name="stopien" value="dyplomowany">dyplomowany
        <br><br>
        <label for="">staż pracy</label>
        <input type="number" name="staz" id="staz">
        <br><br>
        <button type="submit">zatwierdz</button>
    </form>

    <?php
    $nazwisko = $_POST['nazwisko'];
    $przedmioty = $_POST['przedmiot'];
    $stopien = $_POST['stopien'];
    $staz = $_POST['staz'];

    echo "$nazwisko naucza przedmiotów ";
    for($i=0;$i<sizeof($przedmioty);$i++){  //wypisanie przedmiotów ktorych naucza 
    echo"$przedmioty[$i] ";
    }
    echo"<br>";
    echo"stopień zaawansowania to: $stopien <br>";
    echo"Naucza $staz";
    echo"<br><br>";

    switch($stopien){     //wypisanie poszczegolnych opcji zarobkowych

    case 'starzysta';
    $wyplata = 3000;
    $wyplata = $wyplata + ($staz * 100);
    echo"$nazwisko zarabia $wyplata";
    break;

    case'mianowany';
    $wyplata = 3500;
    $wyplata = $wyplata + ($staz * 100);
    echo"$nazwisko zarabia $wyplata";
    break;

    case'dyplomowany';
    $wyplata = 4000;
    $wyplata = $wyplata + ($staz * 100);
    echo"$nazwisko zarabia $wyplata";
    break;
                    
    default:
    # code...
    break;
    }






    ?>
    
</body>
</html>