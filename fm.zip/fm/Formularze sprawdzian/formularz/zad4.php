<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kwiaciarnia</title>
</head>
<body>
    <form action="zad4.php" method="POST">
    <h3>Kwiaciarnia</h3>
    <label for="">Wybierz kwiat</label>
    <select name="kwiaty" id="kwiaty">
<?php
$plik = fopen('dane.txt','r');                                                 
for($i=0;$i<6;$i++){  //wypisanie zawartosci pliku: kwaty  w formularzu
    $k = fgets($plik);
    $kwiat = explode(" ",$k);  //wykazanie ich za pomoca tablicy
    echo"<option value='$k'>$kwiat[0]</option>";
}


?>

    </select>
    <br><br>
    <label for="">ilość sztuk</label>
    <input type="number" name="sztuki" id="sztuki" max=128 min=1>
    <br><br>
    <label for="">przyozdobienia</label>
    <input type="checkbox" name="ok" id="ok">
    <br><br>
    <button type="submit">zatwierdź</button>

    </form>

    <?php
    $kwiaty = $_POST['kwiaty'];
    $sztuki = $_POST['sztuki'];
    $czekbox = $_POST['ok'];

    $kwiat = explode(" ",$kwiaty);
    $cena = $kwiat[2]*$sztuki;

    if(isset($czekbox) == true){
        echo"Kupiłeś $kwiat[0] sztuk $sztuki kolor $kwiat[1].Przyozdonienei:  TAK";
        echo"<br>";
        echo "Cena w złotówkach za wszysto to: ".$cena +=20;

    }else{
        echo "Kupiłeś $kwiat[0] sztuk $sztuki kolor $kwiat[1]. Nie";
        echo $cena;
    }


    ?>
</body>
</html>