<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="zad3.php" method="POST">
        <input type="text" name="nazwisko" placeholder="Podaj nazwisko">
        <br><br>
        <label for="">Zawód który uprawiasz</label>
        <select name="zawody" id="zawody">
        <?php
        $plik=fopen("dane.txt",'r');
        for($i=0;$i<8;$i++){
            $zawod = fgets($plik);
            echo"<option>$zawod</option>";
            echo"<br>";
        }
        ?>

        </select>
        <br>
        <button type="submit">zatwierdź</button>
    </form>
    <?php
        $zapis=fopen("wyniki.txt",'a');
        $nazwisko=$_POST['nazwisko'];
        $wybor = $_POST['zawody'];
        echo"$nazwisko wykonuje zawód $wybor.";
        fwrite($zapis,"$nazwisko wykonuje zawód $wybor. \n");

        ?>

</body>
</html>