<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="" method="POST">
    <label for="jezyk">Jakich języków obcych sie uczysz?</label>
 <select id="jezyk" name="jezyk[]" multiple>
        <option value="angielski">angielski</option>
        <option value="szwedzki">szwedzki</option>
        <option value="niemiecki">niemiecki</option>
        <option value="czeski">czeski</option>
        <option value="rosyjski">rosyjski</option>
        <option value="hiszpański">hiszpański</option>
        <option value="chiński">chiński</option>
        <option value="koreański">koreański</option>
 </select>
 <input type="submit" value="Potwierdź"> 

    </form>

    <?php
        $tab = $_POST['jezyk'];
            echo "Wybrałeś języki/język:<br>";
        for ($i = 0; $i < sizeof($tab); $i++) {
            echo "-".$tab[$i]."<br>";
        }
    ?>
</body>
</html>