<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Powtórka do sprawdzianu</title>
</head>
<body>
    <h2>Generowanie ciągu arytmetycznego</h2>
    <form action=""method="POST">
     <label for="">Pierwszy wyraz A1</label>
     <input type="number" name="A1" id="A1"><br> 
     <label >Wybierz interwał:</label>
 <select name="interwał">
        <option value="ciąg_arytmetyczny">Ciąg arytmetyczny</option>
        <option value="ciąg_geometryczny">Ciąg geometryczny</option>
 </select>
     <label for="">Liczba wyrazów w ciągu N</label>
     <input type="number" name="N" id="N"><br>
     <button type="submit">Oblicz</button> 
    </form>
    <?php
    function potega($a,$n){
        $pot = 1;
        for($i=1;$i<=$n;$i++){
        $pot = $pot*$a;
        }
     return $pot;
        
    }
    
    $ciąg = 0;
    $A1 = $_POST['A1'];
    $R = $_POST['R'];
    $N = $_POST['N'];

    echo "<p>Ciąg arytmetyczny zawiera wyrazy: ";
    for($i=1;$i<=$N;$i++){
        echo "$A1, ";
        $A1 = $A1 + $R;
    }
    
    
    
    
    ?>
</body>

</html>