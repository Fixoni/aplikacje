
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        body{
            text-align:center ;
        }
    </style>
</head>
<body>
<?php
//szerokość długośc wysokość
//rodzaj pędzel wąski/szeroki
//lista rozwijalna rodzaj farby lateksowa=35zl/akrylowe=25zl/winylowa=30zl m2
//przycisk konfidenta
//powierzchnia  do pamalowania $powierzchnia  m2
//koszt farby $koszt zł
//czas malowania wąski 15min/szeroki 5min na m2 zamiana na godziny czas malowania $czas
?>
    <h2>Obliczenia kosztu malowania mieszkania</h2>
    <form action="zad1.php" method="POST">
        <input type="number" name="szerokosc" id="1" placeholder="Podaj szerokość">
        <br><br>
        <input type="number" name="dlugosc" id="2" placeholder="Podaj długość">
        <br><br>
        <input type="number" name="wysokosc" id="3" placeholder="Podaj wysokość">
        <br><br>
        <label for="pedzel">Rodzaj pędzla:</label>
        <br>
        <label for="pedzel">Wąski</label>
        <input type="radio" name="pedzel" value="waski"><br>
        <label for="pedzel">Szeroki</label>
        <input type="radio" name="pedzel" value="szeroki">
        <br><br>
        <select name="farba" id="4">
            <option value="lateks">farba lateksowa</option>
            <option value="akryl">farba akrylowa</option>
            <option value="winyl">farba winylowa</option>
        </select>
        <br><br>
        <input type="submit" value="oblicz">

    </form>
    <?php

        // function isEmpty($var) {
        //     if (isset($var) && is_numeric())
        // }        

    if ((empty($_POST['szerokosc']) && is_numeric($_POST['szerokosc'])) || (empty($_POST['dlugosc']) && is_numeric($_POST['dlugosc'])) || (empty($_POST['wysokosc']) && is_numeric($_POST['wysokosc'])))
        {
            echo "Dane nie mogą wymnosić zero";
        }
        else if (empty($_POST['szerokosc']) || empty($_POST['dlugosc']) || empty($_POST['wysokosc']) || empty($_POST['pedzel']))
        {
            echo "Podaj dane";
        }
        else 
        {
            $szer = $_POST['szerokosc'];
            $dlug = $_POST['dlugosc'];
            $wys = $_POST['wysokosc'];
            
            $pedzel = $_POST['pedzel'];
            $farba = $_POST['farba'];
    
            $pow = $szer*$dlug+2*$szer*$wys+2*$dlug*$wys; 
    
            echo "powierzchnia  do pomalowania: $pow m2<br>";
    
            switch ($farba) {
                case 'lateks':
                    $koszt = $pow * 35;
                    echo "koszt malowania farbą lateksową to: ".$koszt." zł<br>";
                    break;
    
                case 'akryl':
                    $koszt = $pow * 25;
                    echo "koszt malowania farbą akrylową to: ".$koszt." zł<br>";
                    break;
    
                case 'winyl':
                    $koszt = $pow * 30;
                    echo "koszt malowania farbą winylową to: ".$koszt." zł<br>";
                    break;
                
                default:
                    # code...
                    break;
    
            }
            if($pedzel == "szeroki")
            {
                echo "Czas malowania szerokim pędzlem wynosi: ".($pow*5/60)." godzin";
            }
            else
            {
                echo "Czas malowania wąskim pędzlem wynosi: ".($pow*15/60)." godzin";
            }
        }
       


    ?>

</body>
</html>
