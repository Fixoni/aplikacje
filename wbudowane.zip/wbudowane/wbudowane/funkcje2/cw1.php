<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="" method="POST">
        <label>Podaj imie:</label>
        <input type="text" name="i">
        <br>
        <label>Podaj nazwisko:</label>
        <input type="text" name="n">
        <br>
        <button type="submit">Wyślij</button>
    </form>
</body>
</html>

<?php
error_reporting(0);
$i=$_POST['i'];
$n=$_POST['n'];

echo "imie: ".ucfirst($i)." nazwisko: ".ucfirst($n)."<br>";
echo "imie: ".strtoupper($i)." nazwisko: ".strtoupper($n)."<br>";
echo "imie: ".strtolower($i)." nazwisko: ".strtolower($n)."<br>";
echo "imie: ".strtolower($i)." nazwisko: ".substr($n,2,3)."<br>";

$a="alamakota";

echo substr($a,5,7)."<br>";

$b="ala ma dzisiaj matematyke";

echo substr_count($b,"ma")."<br>";
echo substr_count($b,"t")."<br>";

echo substr_replace($b,"*",5)."<br>";

$c="ala nie ma matematyki";

echo substr_replace($c,"**",8,2)."<br>";

$d="  ala ma           ";
$d=trim($d);
echo strlen($d)."<br>";
echo $d."<br>";

for($i=97;$i<=122;$i++) {
    echo $i."--->".chr($i)."<br>";
}
echo "<br>";
echo ord(":")."<br>";

$e="fizyka";
echo str_shuffle($e)."<br>";

?>