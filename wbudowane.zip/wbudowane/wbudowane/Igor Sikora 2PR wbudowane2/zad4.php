<?php
$d=date("Y-m-d");
echo $d."<br>";
$dzis = strtotime(date("Y-m-d"));
$koniec = strtotime("03-05-2024");
$ilezostalo = ceil(($koniec - $dzis) / (60 * 60 * 24));
echo "Pozostało $ilezostalo dni do 3 maja.";
?>