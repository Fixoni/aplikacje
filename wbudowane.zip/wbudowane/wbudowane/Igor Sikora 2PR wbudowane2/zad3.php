<?php
$y=rand(5,10);

$tab[$y]=array();

echo "Tablica: ";

for($i=0;$i<count($tab);$i++) {
    $x=rand(10,20);
    $tab[$i]=$x;
    echo $tab[$i]." ";
}
echo "<br> Sortowanie tablicy malejaco: ";

rsort($tab);
for($i=0;$i<count($tab);$i++) {
    echo $tab[$i]." ";
}
echo "<br> Potasowanie tablicy: ";

shuffle($tab);
for($i=0;$i<count($tab);$i++) {
    echo $tab[$i]." ";
}
echo "<br> Tablica po dodaniu liczb 555,666,777 na poczatek: ";

array_unshift($tab,555,666,777);
foreach ($tab as $value) {
    echo $value." ";
}
echo "<br>";

foreach ($tab as $key => $value) {
    echo "[".$key."] ".$value."<br>";
}

echo "Usunięte 3 elementy z tablicy, począwszy od drugiego: ";
$usuniete_elementy = array_splice($tab, 1, 3);
foreach ($usuniete_elementy as $element) {
    echo $element." ";
}
echo "<br>";

echo "Tablica po usunięciu elementów: <br>";
foreach ($tab as $key => $value) {
    echo "[".$key."] ".$value."<br>";
}

?>