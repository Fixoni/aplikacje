<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formularz</title>
</head>
<body>
    <form action="" method="POST">
        <label for="miejscowosc">Podaj nazwę miejscowości:</label>
        <input type="text" id="miejscowosc" name="miejscowosc">
        <button type="submit">Wyślij</button>
    </form>
</body>
</html>

<?php
    $zapis=fopen("zapis.txt","a");
    $miejscowosc = $_POST["miejscowosc"];
    
    $ascii = ord($miejscowosc[0]);
    
    if ($asci % 2 == 0) {
        fwrite($zapis,"$ascii ");
    }
    
    $miejscowosc = str_replace('a', '$', $miejscowosc);
    
    $miejscowosc = ucwords($miejscowosc);
    
    echo "Nowa nazwa miejscowości: $miejscowosc";
?>
