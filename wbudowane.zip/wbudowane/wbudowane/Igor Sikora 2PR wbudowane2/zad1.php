<?php
$odczyt=fopen("dane.txt","r");
$a=intval(fgets($odczyt));
$b=intval(fgets($odczyt));
$c=intval(fgets($odczyt));

echo  "Liczby: ".$a." ".$b." ".$c."<br>";

$s=$a+$b+$c;
echo "Suma: ".$s."<br>";
$d=sqrt($s);
echo "Pierwiastek: ".$d."<br>";
$e=round($d,2);
echo "Zaokrąglenie: ".$e."<br>";
$f=pow($a,$b);
echo "Potęga liczby a do liczby b: ".$f."<br>";
$g=decbin($f);
echo "Ósemkowy: ".$g."<br>";
$h=dechex($f);
echo "Szesnastkowy: ".$h."<br>";

$i = 60;
$j = deg2rad($i); 
echo "<br>Radiany kąta 60 stopni: " . $j;
$k = cos($j); 
echo "<br>cosinus 60 stopni: " . $k;
?>