<?php

$a = "Ala idzie do szkoły i tam spotyka się z Olą";
echo $a . "<br>";

for ($i = 0; $i < strlen($a); $i++) {
    if ($i % 2 == 0) {
        echo strtoupper($a[$i]);
    } else {
        echo strtolower($a[$i]);
    }
}

echo "<br>";
$word_to_cut = "tam";
$pos = strpos($a, $word_to_cut);
if ($pos !== false) {
    $cut_word = substr($a, $pos, strlen($word_to_cut));
    echo "Wytnięte słowo: $cut_word<br>";

    $sentence_without_word = str_replace($cut_word, "", $a);
    echo "Zdanie bez słowa \"$word_to_cut\": $sentence_without_word<br>";
}

$replacement = "Basia";
$replaced_sentence = str_replace("Ala", $replacement, $a);
echo $replaced_sentence;
?>
