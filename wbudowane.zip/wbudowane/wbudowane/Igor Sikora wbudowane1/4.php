<?php
$d=date("Y-m-d");
echo $d."<br>";
$current_date = strtotime(date("Y-m-d"));
$may_1_date = strtotime("2024-05-01");
$days_until_may_1 = ceil(($may_1_date - $current_date) / (60 * 60 * 24));
echo "Pozostało $days_until_may_1 dni do 1 maja.";
?>
