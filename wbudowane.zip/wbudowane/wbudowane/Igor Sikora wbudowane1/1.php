<?php

$plik = fopen("dane.txt", "r");
$a = floatval(fgets($plik));
$b = floatval(fgets($plik));
$e = floatval(fgets($plik)); 

echo $a . " " . $b . " " . $e;

$s = $a + $b + $e;
echo "<br>Suma: " . $s;
$c = sqrt($s); 
echo "<br>Pierwiastek z sumy: " . round($c, 2); 
$f = ceil($a); 
echo "<br>Zaokrąglona w górę pierwsza liczba: " . $f;
$g = floor($b); 
echo "<br>Zaokrąglona w dół druga liczba: " . $g;
$i = pow($f, $g);
echo "<br>Potęga: " . $i;
$j = decbin($i); 
echo "<br>Potęga w postaci binarnej: " . $j;
$h = dechex($i); 
echo "<br>Potęga w postaci szesnastkowej: " . $h;

$l = 30;
$m = deg2rad($l); 
echo "<br>Radiany kąta 30 stopni: " . $m;
$n = sin($m); 
echo "<br>Sinus 30 stopni: " . $n;
?>
