<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="" method="POST">
        <label for="">Podaj rozmiar tablicy</label>
        <input type="number" name="rozmiar">
        <button type="submit">Generuj tablicę</button>
    </form>
</body>
</html>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $rozmiar = $_POST["rozmiar"];

    $tab = array();
    
    echo "Wygenerowana tablica: ";
    for ($i = 0; $i < $rozmiar; $i++) {
        $tab[$i] = rand(1, 99);
        echo $tab[$i] . " ";
    }
    echo "<br>";
    
    echo "Posortowana tablica malejąco: ";
    rsort($tab);
    foreach ($tab as $element) {
        echo $element . " ";
    }
    echo "<br>";
    
    $liczba_do_sprawdzenia = 15;
    echo "Czy liczba 15 istnieje w tablicy: ";
    $czy_istnieje = in_array($liczba_do_sprawdzenia, $tab) ? "Tak" : "Nie";
    echo $czy_istnieje . "<br>";
    
    echo "Ilość wystąpień liczby 15 w tablicy: ";
    $ilosc_wystapien = array_count_values($tab)[$liczba_do_sprawdzenia] ?? 0;
    echo $ilosc_wystapien . "<br>";
    
    echo "Suma elementów tablicy: ";
    $suma = array_sum($tab);
    echo $suma . "<br>";
    
    echo "Tablica po dodaniu liczb 555, 666, 777 na koniec: ";
    array_push($tab, 555, 666, 777);
    foreach ($tab as $element) {
        echo $element . " ";
    }
    echo "<br>";
    
    echo "Usunięte 3 elementy z tablicy, począwszy od drugiego: ";
    $usuniete_elementy = array_splice($tab, 1, 3);
    foreach ($usuniete_elementy as $element) {
        echo $element . " ";
    }
    echo "<br>";
    
    echo "Tablica po usunięciu elementów: ";
    foreach ($tab as $element) {
        echo $element . " ";
    }
}
?>
