<?php
$odczyt=fopen("dane.txt","r");
$a=fgets($odczyt);
echo "Rozmiar tablicy: ".$a;
$tab=array($a);
echo "<br>";
echo "Tablica <b>NIE</b> posortowana: ";
echo "<br>";
for($i=0;$i<$a;$i++) {
    $tab[$i]=rand(1,100);
    echo $tab[$i]." ";
}
echo "<br>";

sort($tab);
echo "Tablica posortowana: ";
echo "<br>";
for($i=0;$i<$a;$i++) {
    echo $tab[$i]." ";
}
echo "<br>";

$b=array_count_values($tab)[15];
echo "Ilość liczby 15 w tablicy: ".$b."<br>";
array_pop($tab);
$c=count($tab);
echo "Rozmiar tablicy po usunieciu ostatniej liczby: ".$c."<br>";

echo "Dodawanie elementów do tablicy <br>";
$d=array_push($tab,777,888,999);
echo $d;
for($i=0;$i<count($tab);$i++) {
    echo $tab[$i]." ";
}
echo "<br>";

echo "Dodaanie liczby 1000: ";
echo "<br>";
array_unshift($tab,1000,1000);
for($i=0;$i<count($tab);$i++) {
    echo $tab[$i]." ";
}
echo "<br>";

echo "Sortowanie malejąco: ";
echo "<br>";
rsort($tab);
for($i=0;$i<count($tab);$i++) {
    echo $tab[$i]." ";
}
echo "<br>";

echo "Usuwanie duplikatów w tablicy: ";
echo "<br>";
print_r(array_unique($tab));
echo "<br>";

echo "Funkcja replice: ";
echo "<br>";
$tab2=array(-15,-16,-17);
print_r(array_replace($tab,$tab2));
for($i=0;$i<count($tab);$i++) {
    echo $tab[$i]." ";
}
echo "<br>";

echo "Funckja splice: ";
echo "<br>";
array_splice($tab,5,3,$tab2);
for($i=0;$i<count($tab);$i++) {
    echo $tab[$i]." ";
}
echo "<br>";
$f=array_sum($tab);
echo $f;
echo "<br>";

$tab3=array("Kowalski"=>5.0,
"Sikora"=>6.0,
"Sanowksi"=>4.5,
"Sulewksi"=>5.5,
"Pielak"=>3.5);
echo "<br>";
foreach($tab3 as $nazwisko => $ocena) {
    echo "Uczeń ".$nazwisko." ma śriednią: ".$ocena."<br>";
}
ksort($tab3);
echo "<br>";
echo "Tablica asocjacyjna posortowana według kluczy: ";
echo "<br>";
foreach($tab3 as $nazwisko => $ocena) {
    echo "Uczeń ".$nazwisko." ma śriednią: ".$ocena."<br>";
}
arsort($tab3);
echo "<br>";
echo "Tablica asocjacyjna posortowana według wartości: ";
echo "<br>";
foreach($tab3 as $nazwisko => $ocena) {
    echo "Uczeń ".$nazwisko." ma śriednią: ".$ocena."<br>";
}
echo "<br> Zmiana na duże litery <br>";
foreach($tab3 as $nazwisko => $ocena) {
    echo "Uczeń ".strtoupper($nazwisko)." ma śriednią: ".$ocena."<br>";
}
echo "<br> Zmiana na małe litery <br>";
foreach($tab3 as $nazwisko => $ocena) {
    echo "Uczeń ".strtolower($nazwisko)." ma śriednią: ".$ocena."<br>";
}
echo "<br>";

print_r(array_keys($tab3));
echo "<br>";

print_r(array_merge($tab,$tab2));
echo "<br>";

print_r(array_search(6.0,$tab3));
echo "<br>";

print_r(array_slice($tab3,2,3));
?>