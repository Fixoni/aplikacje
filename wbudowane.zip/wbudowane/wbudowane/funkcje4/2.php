<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="" method="POST">
        <label> Liczba b</label>
        <input type="number" name="b"> <br>
        <label>Liczba c</label>
        <input type="number" name="c"> <br>
        <button type="submit">Wyślij</button>
    </form>
</body>
</html>



<?php
// z pliku pobierz liczby będąca rozmiarem tablicy a z formularza dwie liczby
// bedące zakresem losowania liczb do tablicy
// wyświetl elementy tablicy posortuj ją malejąco dodaj na końcu liczby 100 200 300
// z tablicy utwórz łańcuch potasuj znaki w tym łańcuchu i wyznacz sume kodów aski wszystkich elementów
// znajdujących się w łańcuchu

$b=$_POST["b"];
$c=$_POST["c"];




$plik=fopen("dane.txt","r");
$a=fgets($plik);
echo "Rozmiar tablicy: ".$a."<br>";

$tab=array($a);

for($i=0;$i<$a;$i++) {
    $tab[$i]=rand($b,$c);
    echo $tab[$i]." ";
}

echo "<br> Tablica posortowana: <br>";
rsort($tab);
for($i=0;$i<$a;$i++) {
    echo $tab[$i]." ";
}

echo "<br> Dodanie liczb na końcu <br>";
array_push($tab,100,200,300);
count($tab);

for($i=0;$i<count($tab);$i++) {
    echo $tab[$i]." ";
}

echo "<br> Zamiana na string <br>";
$d=implode($tab);
echo $d."<br>";

echo "<br> Tasowanie <br>";
$f=shuffle($d);
echo "<br>";
echo $f." ";


$s=0;
for($i=0;$i<$d;$i++) {
    $s=$s+ord($d[$i]);
}





?>