<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="">

    </form>
</body>
</html>

<?php
$date=getdate();



$dzien=$date["mday"];
$miesiac=$date["mon"];

switch($dzien) {
    case 0:
        echo "Poniedziałek";
    break;
    case 1:
        echo "Wtorek";
    break;
    case 2:
        echo "Środa";
    break;
    case 3:
        echo "Czwartek";
    break;
    case 4:
        echo "Piątek";
    break;
    case 5:
        echo "Sobota";
    break;
    case 6:
        echo "Niedziela";
    break;
    default:
        echo "Nie ma takiego dnia";
    break;
}

switch($miesiac) {

    case 1:
        echo "Styczen";
    break;
    case 2:
        echo "Luty";
    break;
    case 3:
        echo "Marzec";
    break;
    case 4:
        echo "Kwiecien";
    break;
    case 5:
        echo "Maj";
    break;
    case 6:
        echo "Czerwiec";
    break;
    case 7:
        echo "Lipiec";
    break;
    case 8:
        echo "Sierpień";
    break;
    case 9:
        echo "Wrzesień";
    break;
    case 10:
        echo "Październik";
    break;
    case 11:
        echo "Listopad";
    break;
    case 12:
        echo "Grudzień";
    break;
    default:
        echo "Nie ma takiego dnia";
    break;
}
    $rok=$date["year"];

echo "Dziś jest: ".$dzien." ".$miesiac." ".$year."<br>";
$dd=getdate();
$w=$dd["weekday"];
$m=$dd["month"];
$y=$dd["year"];
echo "Dziś mamy: ".$w." ".$m." ".$y;

$d=date("d-m-Y");
echo "<br>".$d."<br>";
echo "Do wakacji zostało: ";



?>