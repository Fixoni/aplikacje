using System;
using System.Drawing;
using System.Windows.Forms;

public class notepad : Form {

    Button ok = new Button();
    TextBox text = new TextBox();
    TextBox login = new TextBox();
    TextBox password = new TextBox();

    static public void Main () {

        Application.Run(new notepad ());

    }
    public notepad() {

        this.Size = new Size(400,200);
        this.StartPosition = FormStartPosition.CenterScreen;

        ok.Size = new Size(64,64);
        ok.Location = new Point(10,10);
        ok.Click += new EventHandler(ok_click);
        ok.Text = "OK";
        this.Controls.Add(ok);

        text.Size = new Size(40,30);
        text.Location = new Point(100,10);
        text.Font = new Font(text.Font.FontFamily,24);
        this.Controls.Add(text);

        login.Size = new Size(40,30);
        login.Location = new Point(100,100);
        login.Font = new Font(text.Font.FontFamily,24);
        this.Controls.Add(login);

        password.Size = new Size(40,30);
        password.Location = new Point(100,160);
        password.Font = new Font(text.Font.FontFamily,24);
        this.Controls.Add(password);
    }
    private void ok_click(object sender, EventArgs e){
        
        if (text.Text == "1111")
        {
        MessageBox.Show("Top Secret");
        }
    }
}