using System;
using System.Drawing;
using System.Windows.Forms;

public class notepad : Form {

    MainMenu menu = new MainMenu();
    RichTextBox notatnik = new RichTextBox();
    static public void Main (){

        Application.Run(new notepad());
        //elementy menu
        MainMenu menu = new MainMenu();
    }

    public notepad(){

        this.Size = new Size(800,600);
        this.StartPosition = FormStartPosition.CenterScreen;
        this.Text = "Notatnik";
        //elementy menu
        MenuItem plik = new MenuItem();
        MenuItem nowy = new MenuItem();
        MenuItem otworz = new MenuItem();
        MenuItem zapisz = new MenuItem();
        MenuItem drukuj = new MenuItem();
        MenuItem edycja = new MenuItem();
        MenuItem kopiuj = new MenuItem();
        MenuItem wklej = new MenuItem();
        MenuItem wytnij = new MenuItem();
        MenuItem zamknij = new MenuItem();
        MenuItem kolor = new MenuItem();
        MenuItem czcionka = new MenuItem();



        plik.Text = "&Plik";
        nowy.Text = "&Nowy";
        otworz.Text = "&Otówrz";
        zapisz.Text = "&Zapisz";
        drukuj.Text = "&Drukuj";
        edycja.Text = "&Edycja";
        kopiuj.Text = "&Kopiuj";
        wklej.Text = "&Wklej";
        wytnij.Text = "&Wytnij";
        zamknij.Text = "&Zamknij";
        kolor.Text = "&Kolor";
        czcionka.Text = "&Czcionka";
        otworz.Shortcut = Shortcut.CtrlO;
        zapisz.Shortcut = Shortcut.CtrlS;
        drukuj.Shortcut = Shortcut.CtrlP;
        kopiuj.Shortcut = Shortcut.CtrlC;
        wklej.Shortcut = Shortcut.CtrlV;


        nowy.Click += new EventHandler(nowy_click);
        otworz.Click += new EventHandler(otworz_click);
        zapisz.Click += new EventHandler(zapisz_click);
        drukuj.Click += new EventHandler(drukuj_click);
        wklej.Click += new EventHandler(wklej_click);
        wytnij.Click += new EventHandler(wytnij_click);
        kopiuj.Click += new EventHandler(kopiuj_click);
        zamknij.Click += new EventHandler(exit_click);
        kolor.Click += new EventHandler(kolor_click);
        kolor.Click += new EventHandler(kolor_click);
        czcionka.Click += new EventHandler(czcionka_click);

        menu.MenuItems.Add(plik);
        plik.MenuItems.Add(nowy);
        plik.MenuItems.Add(otworz);
        plik.MenuItems.Add(zapisz);
        plik.MenuItems.Add(drukuj);
        plik.MenuItems.Add(zamknij);
        plik.MenuItems.Add(kolor);
        menu.MenuItems.Add(edycja);
        edycja.MenuItems.Add(kopiuj);
        edycja.MenuItems.Add(wklej);
        edycja.MenuItems.Add(wytnij);


        this.Menu = menu;
        notatnik.Font = new Font(notatnik.Font.FontFamily,24);
        notatnik.Dock = DockStyle.Fill;
        this.Controls.Add(notatnik);
    }
        private void nowy_click(Object sender, EventArgs e){
            if(notatnik.Text != "")
        {
            DialogResult dialog = MessageBox.Show("Czy jesteś pewny?","Czyszczenie",MessageBoxButtons.YesNo);
            if (dialog == DialogResult.Yes)

            {
            notatnik.Clear();
            }
        }
    }
        private void otworz_click(Object sender, EventArgs e){

        OpenFileDialog dialog = new OpenFileDialog();
        dialog.Title= "otworz plik";
        dialog.Filter = "pliki RFT|.rtf";

        if (dialog.ShowDialog() == DialogResult.OK)
        {
            try
            {
                notatnik.LoadFile(dialog.FileName);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }
    }

        private void zapisz_click(Object sender, EventArgs e){

        SaveFileDialog dialog = new SaveFileDialog();
        dialog.Title="zapisz plik";
        dialog.Filter = "pliki RFT|.rtf";

        if (dialog.ShowDialog() == DialogResult.OK){

            notatnik.SaveFile(dialog.FileName);
        }
    }
private void drukuj_click(Object sender, EventArgs e){

        PrintDialog dialog = new PrintDialog();
         if (dialog.ShowDialog() == DialogResult.OK){

            //drukowanuie

        }

    }
    private void kopiuj_click(object sender, EventArgs e)
    {
        notatnik.Copy();
    }
    private void wklej_click(object sender, EventArgs e)
    {
        notatnik.Paste();
    }
    private void wytnij_click(object sender, EventArgs e)
    {
        notatnik.Cut();

    }
    private void kolor_click(object sender,EventArgs e)
    {
        ColorDialog dialog = new ColorDialog();
        if(dialog.ShowDialog() == DialogResult.OK)
        {
            notatnik.SelectionColor = dialog.Color;
        }      
    }
        private void czcionka_click(object sender,EventArgs e)
    {
        FontDialog dialog = new FontDialog();
        if(dialog.ShowDialog() == DialogResult.OK)
        {
            notatnik.SelectionFont = dialog.Font;
        }
    }
    private void exit_click(Object sender, EventArgs e){
            if(notatnik.Text != "")
        {
            DialogResult dialog = MessageBox.Show("Czy jesteś pewny?","Czyszczenie",MessageBoxButtons.YesNo);
            if (dialog == DialogResult.Yes)

            {
            this.Close();
            }
        }
        else
        {
            this.Close();
        }
    }


}