using System;
using System.Drawing;
using System.Windows.Forms;

public class notepad : Form {
    Button przycisk;
    TextBox tb;
    static public void Main () {

        Application.Run(new notepad ());

    }
    public notepad() {
        this.Size = new Size(800, 600);
        this.StartPosition = FormStartPosition.CenterScreen;
        this.BackColor = Color.FromArgb(200, 200, 200);

        tb = new TextBox();
        tb.Size = new Size(200,100);
        tb.Location = new Point(10,10);

        przycisk = new Button();
        przycisk.Size = new Size(200,100);
        przycisk.BackColor = Color.FromArgb(100,100,100);
        przycisk.Location = new Point(230,10);
        przycisk.Font = new Font(przycisk.Font.FontFamily, 24);
        przycisk.Click += new EventHandler(ButtonClicked);
        przycisk.Text = "Kliknij mnie";
        this.Controls.Add(tb);
        this.Controls.Add(przycisk);
    }
    void ButtonClicked(Object sender, EventArgs e) {
        Button clickedButton = (Button)sender;
        clickedButton.Text = tb.Text;
    }
}