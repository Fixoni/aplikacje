﻿
using var game = new MyGame_2.Game1();
game.Run();
