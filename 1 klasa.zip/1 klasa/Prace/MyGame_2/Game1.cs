﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace MyGame_2;

public class Game1 : Game
{
    private GraphicsDeviceManager _graphics;
    private SpriteBatch _spriteBatch;

    private Texture2D player;
    private Texture2D player_right;
    private Vector2 player_xy;
    private Texture2D tlo;
    private Vector2 pudlo_xy;
    private Texture2D pudlo;
    private Vector2 tlo_xy;
    private bool skok = false;
    private float czas_skoku = 0.0f;
    private float startY = 0;
    private float kat = 0.0f;
    private float elapsed;
    private float delay = 200f;
    private int frames;
    private Rectangle animacja;
    private SpriteEffects obrota;
    public Game1()
    {
        _graphics = new GraphicsDeviceManager(this);
        Content.RootDirectory = "Content";
        IsMouseVisible = true;
        if (GraphicsDevice == null)
        {
        _graphics.ApplyChanges();
        }

        _graphics.PreferredBackBufferWidth=1194;
        _graphics.PreferredBackBufferHeight=499;

        _graphics.ApplyChanges();
    }

    protected override void Initialize()
    {
        // TODO: Add your initialization logic here

        base.Initialize();
    }

    protected override void LoadContent()
    {
        _spriteBatch = new SpriteBatch(GraphicsDevice);
        player = Content.Load<Texture2D>("idle");
        tlo = Content.Load<Texture2D>("tlo");
        pudlo =  Content.Load<Texture2D>("box");
        pudlo_xy.Y = 400;
        pudlo_xy.X = 300;
        player_xy.Y = 300;
        tlo_xy.X = -3;
        tlo_xy.Y = -100;
        startY =player_xy.Y;
       // TODO: use this.Content to load your game content here
    }

    protected override void Update(GameTime gameTime)
    {
        if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
            Exit();
            KeyboardState klawisz = Keyboard.GetState();
            if(skok)
            {
                player_xy.Y += czas_skoku;
                czas_skoku += 1;
                if(player_xy.Y >= startY)
                {
                    player_xy.Y = startY;
                    skok = false;
                }
            }
            else
            {
                if(klawisz.IsKeyDown(Keys.Up)){
                skok = true;
                czas_skoku = -20;
                }
            }
            //sterowanie
            if(player_xy.X+100 < 1000)
           // {
                if(klawisz.IsKeyDown(Keys.Right))
                {
                    player_xy.X+=3;
                    obrota = SpriteEffects.None;
                player = Content.Load<Texture2D>("walk");
                }
           // }
           if(player_xy.X > -100)
           {
                if(klawisz.IsKeyDown(Keys.Left))
                {
                    player_xy.X -= 3;
                    obrota = SpriteEffects.FlipHorizontally;
                    player = Content.Load<Texture2D>("walk");
                }
           }
                if(klawisz.IsKeyUp(Keys.Right) && klawisz.IsKeyUp(Keys.Left))
                {
                    player = Content.Load<Texture2D>("idle");
                }

        //animacja
        elapsed += (float) gameTime.ElapsedGameTime.TotalMilliseconds;
        if(elapsed >=delay)
        {
            if(frames >= 3)
            {
                frames = 0;
            }
            else
            {
                frames++;
            }
            elapsed = 0;
        }    
        animacja = new Rectangle(128*frames,0,128,127);
        // TODO: Add your update logic here
        if( (pudlo_xy.X- 50 < player_xy.X) && (pudlo_xy.X > player_xy.X))
        {
            if(player_xy.Y < 50)
            {
            startY = 50;
            }
        }
            else{
                startY = 199;
                if((klawisz.IsKeyDown(Keys.Left))||klawisz.IsKeyDown(Keys.Right))
                {
                    skok = true;
                }
            }


        base.Update(gameTime);
    }

    protected override void Draw(GameTime gameTime)
    {
        GraphicsDevice.Clear(Color.CornflowerBlue);
        _spriteBatch.Begin();
        Vector2 obrot = new Vector2();
        _spriteBatch.Draw(tlo,tlo_xy,null,Color.White,kat,obrot,1f,SpriteEffects.None,1);
        _spriteBatch.Draw(player,player_xy,animacja,Color.White,kat,obrot,1.6f,obrota,1);
        _spriteBatch.Draw(pudlo,pudlo_xy,null,Color.White,kat,obrot,1f,SpriteEffects.None,1);
        _spriteBatch.End();
        // TODO: Add your drawing code here

        base.Draw(gameTime);
    }
}
