using System;
using System.Drawing;
using System.Windows.Forms;

public class notepad : Form
{

        //menu główne
        MainMenu menu = new MainMenu();

        //miejsce do wpisywania tekstu
        RichTextBox notatnik = new RichTextBox();

    static public void Main () 
    {

        Application.Run(new notepad ());

    }
    public notepad()
    {
        //elemnty notatnika
        this.Size = new Size(800, 600);
        this.StartPosition = FormStartPosition.CenterScreen;
        this.Text = "Notatnik 3.0 HD";

        //elementy plik
        MenuItem plik = new MenuItem();
        MenuItem nowy = new MenuItem();
        MenuItem otworz = new MenuItem();
        MenuItem zapisz = new MenuItem();
        MenuItem drukuj = new MenuItem();

        //nazwy przycisków do sekcji plik
        plik.Text = "&Plik";
        nowy.Text = "&Nowy";
        otworz.Text = "&Otwórz";
        zapisz.Text = "&Zapisz jako...";
        drukuj.Text = "&Drukuj";

        //wyświetlanie przycisków menu
        menu.MenuItems.Add(plik);
        plik.MenuItems.Add(nowy);
        plik.MenuItems.Add(otworz);
        plik.MenuItems.Add(zapisz);
        plik.MenuItems.Add(drukuj);

        //skróty dla plik
        nowy.Shortcut = Shortcut.CtrlN;
        otworz.Shortcut = Shortcut.CtrlO;
        zapisz.Shortcut = Shortcut.CtrlS;
        drukuj.Shortcut = Shortcut.CtrlP;

        //elementy edycja
        MenuItem edycja = new MenuItem();
        MenuItem kopiuj = new MenuItem();
        MenuItem wklej = new MenuItem();
        MenuItem usun = new MenuItem();
        MenuItem wytnij = new MenuItem();

        //nazwy przycisków do sekcji edycja
        edycja.Text = "&Edycja";
        kopiuj.Text = "&Kopiuj";
        wklej.Text = "&Wklej";
        usun.Text = "&Usuń";
        wytnij.Text = "&Wytnij";

        //wyświetlanie przycisków menu
        menu.MenuItems.Add(edycja);
        edycja.MenuItems.Add(kopiuj);
        edycja.MenuItems.Add(wklej);
        edycja.MenuItems.Add(wytnij);
        edycja.MenuItems.Add(usun);

        //skróty dla edycja
        kopiuj.Shortcut = Shortcut.CtrlC;
        wklej.Shortcut = Shortcut.CtrlV;
        usun.Shortcut = Shortcut.Del;
        wytnij.Shortcut = Shortcut.CtrlX;

        //wyświetlanie menu
        this.Menu = menu;


        //miejsce do tekstu
        this.Controls.Add(notatnik);
        notatnik.Dock = DockStyle.Fill;

        //zdarzenia dla przycisków plik
        nowy.Click += new EventHandler(nowy_click);
        otworz.Click += new EventHandler(otworz_click);
        zapisz.Click += new EventHandler(zapisz_click);
        drukuj.Click += new EventHandler(drukuj_click);

        //zdarzenia dla przycisków edycja
        kopiuj.Click += new EventHandler(kopiuj_click);
        wklej.Click += new EventHandler(wklej_click);
        usun.Click += new EventHandler(usun_click);
        wytnij.Click += new EventHandler(wytnij_click);

    }

    private void nowy_click(object sender, EventArgs e)
    {
        notatnik.Clear();
    }
    private void otworz_click(object sender, EventArgs e)
    {
        //otwieranie plików
        OpenFileDialog dialog = new OpenFileDialog();
        dialog.Title = "Otwórz plik";
        if (dialog.ShowDialog() == DialogResult.OK)
        {
            //wczytywanie pliku
            notatnik.LoadFile(dialog.FileName);
        } 
    }
    private void zapisz_click(object sender, EventArgs e)
    {
        //zapisywanie plików
        SaveFileDialog dialog = new SaveFileDialog();
        dialog.Title = "Zapisz plik";
        dialog.Filter = "Pliki txt|*.txt";
        if (dialog.ShowDialog() == DialogResult.OK)
        {
            //okno zapisu
            notatnik.SaveFile(dialog.FileName);
        } 
    }
    private void drukuj_click(object sender, EventArgs e)
    {
        //drukowanie pliku
        PrintDialog dialog = new PrintDialog();
        if (dialog.ShowDialog() == DialogResult.OK)
        {
            //drukowanie

        }
    }
    private void kopiuj_click(object sender, EventArgs e)
    {
        notatnik.Copy();
    }
    private void wklej_click(object sender, EventArgs e)
    {
        notatnik.Paste();
    }
    private void wytnij_click(object sender, EventArgs e)
    {
        notatnik.Cut();
    }
    private void usun_click(object sender, EventArgs e)
    {
        notatnik.Clear();
    }
}