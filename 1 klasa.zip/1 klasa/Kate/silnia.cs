using System;
namespace Name
{
    class program
    {
        public static int dodaj(int x)
        {
        int z= 1;
        x+= 1;
        for(int i=1; i<x; i++)
        {
        z = z*i;
        }
        return z;
        }

        static void Main()
        {
        int x = dodaj(5);
        Console.Write(x);
        }
    }
    }
