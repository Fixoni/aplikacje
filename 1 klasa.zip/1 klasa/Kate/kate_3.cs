using System;

class Program{

    static void dodaj(int x,int y)
    {
            Console.Write(x+y);
    }

    static void Main()
    {
     dodaj(9,14);
    }

}

