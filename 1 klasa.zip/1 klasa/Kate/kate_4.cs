using System;
    using System.IO;
    namespace P {

      class Program {
        static void Main(string[] args) {
            string tak;
            tak = File.ReadAllText("tekst.txt");
            Console.WriteLine(tak);
        }
      }
    }
