using System;

    class Program{

    static void Main();{

        string tekst = "Moje oblicze jest tutaj";
        Console.WriteLine(tekst);
        Console.Write(teskt[1]);
        int x= tekst.Lenght();
        Console.WriteLine("Liczba znaków: " + x);
        Console.WriteLine(tekst.ToUpper());

        string s1 = "ala";
        string s2 = "co ma?";
        Console.WriteLine(String.Concast(s1,s2)

        string zdanie = "małgosia i Jaś poszli do lasu zbierać grzyby"
        if (zdanie.Contains("Małgosia"))
            Console.WriteLine("Znalazłem");

        string[] a = zdanie.Split(new char[] {' '});

        foreach (string s in a)
            Console.WriteLine(s);

    }
}
