Using System;

class Program
{
 static void Main()
    {
        int liczba = 0;
        liczba = Convert.ToInt32(Console.WriteLine());
        if (liczba >0)
        {
        Console.WriteLine("Liczba dodatnia");
        }
        else
        {
        Console.WriteLine("Liczba ujemna");
        }
    }
}
