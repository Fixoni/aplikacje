using System;

public class petla
{
   public static void Main()
   { 
      int[] tab = new int[10];
      tab[2]=3;
      tab[7]=9;

      for (int i=0;i<tab.Length;i++)
      Console.WriteLine(tab[i]);
   }
}