using System;

    class Program
    {
        static void Main()
        {
            //stringi
        string tekst = "Moje oblicze jest tutaj";
        Console.WriteLine(tekst);

        //wypisanie stringa jako tablicy
        Console.Write(tekst[1]);

        //pobieranie długości łańcucha
        int x = tekst.Length;
        Console.WriteLine("liczba znaków: "  + x);

        //drukowanie dużymi literami
        Console.WriteLine(tekst.ToUpper());
        //łączenie stringów
        string s1 = "ala";
        string s2 = " co ma?";
        Console.WriteLine(String.Concat(s1,s2));

        //wyszukiwanie
        string zdanie = "Małgosia i Jas poszli do lasu zbierać grzyby";
        if (zdanie.Contains("Małgosia"))
        Console.WriteLine("Znalazłem");

        //rozbicie łańcucha tekstowego
        string[] a = zdanie.Split(new char[] {' '});

        foreach (string s in a)
            Console.WriteLine(s);
        }
    }