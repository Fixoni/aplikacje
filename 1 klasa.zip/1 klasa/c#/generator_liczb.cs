using System;

    class matrix
    {
        static void Main()
        {

            int x = 10;
            int y = 10;
            int suma = 0;
            Random los = new Random();

            int[,] matrix = new int[x,y]; 


            for (int i=0;i<x;i++)
            {
                for (int j=0;j<y;j++)
                {
                    matrix[i,j]=los.Next(0,10);
                    Console.Write(matrix[i,j] + " ");
                    if (matrix[i,j] == 2)
                    suma++;

                }
                Console.WriteLine();
            }
        Console.WriteLine("Cyfry 2 jest " + suma);
        }
    }