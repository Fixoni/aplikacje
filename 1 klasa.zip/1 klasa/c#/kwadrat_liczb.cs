using System;

class Program
{
    static void Main()
    {
        int[,] arr = new int[6, 6];

        for (int i = 0; i < 6; i++)
        {
            arr[i, 0] = 1;
            arr[i, 5] = 1;
            arr[0, i] = 1;
            arr[5, i] = 1;
        }


        for (int i = 0; i < 6; i++)
        {
            for (int j = 0; j < 6; j++)
            {
                Console.Write(arr[i, j] + " ");
            }
            Console.WriteLine();
            
        }
        Console.ReadLine();
    }
}