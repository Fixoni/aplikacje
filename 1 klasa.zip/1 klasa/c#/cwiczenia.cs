Using System;

class Program
{
 static void Main()
    {
      int liczba = 0;
      liczba = Convert.ToInt32(Console.ReadLine());
      if (liczba%2==0)
      {
      Console.WriteLine("Liczba parzysta");
      }
     else
      {
      Console.WriteLine("Liczba nieparzysta");
      }
    }
}
