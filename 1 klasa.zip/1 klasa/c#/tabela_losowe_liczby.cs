using System;

public class petla
{
   public static void Main()
   { 
      int[] tab = new int[10000];
      Random rnd = new Random();

      for (int i=0;i<tab.Length;i++)
      tab[i] = rnd.Next(0,9);

      for (int i=0;i<tab.Length;i++)
      Console.Write(tab[i] + " ");
   }
}