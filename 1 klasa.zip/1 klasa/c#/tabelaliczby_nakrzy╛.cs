using System;

class Program
{
    static void Main()
    {
        int[,] arr = new int[6, 6];

        for (int i = 0; i < 6; i++)
        {
            arr[i, i] = 1;
        }

        for (int i = 5; i >= 0; i--)
        {
            for (int j = 0; j < 6; j++)
            {
                Console.Write(arr[i, j] + " ");
            }
            Console.WriteLine();

        }
        Console.ReadLine();
    }
}