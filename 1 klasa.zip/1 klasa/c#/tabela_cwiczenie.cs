using System;

public class petla
{
   public static void Main()
   { 
    
      int[,] arr= new int[6,6];
      arr[2,2]=1;



   }
}