using System;

     class Program
    {
        static void Main()
        {
           
            int a = 0;
            int b = 0;
            int c = 0;
            int delta = 0;
            Console.Write("Wpisz a = ");
            a = Convert.ToInt32(Console.ReadLine());
            Console.Write("Wpisbz b = ");
            b = Convert.ToInt32(Console.ReadLine());
            Console.Write("Wpisz c = ");
            c = Convert.ToInt32(Console.ReadLine());
            
            delta=(b*b)-(4*(a*c));
            Console.WriteLine("Delta = " +delta);

            if (a==0)
            {
            Console.WriteLine("Wartość a musi się różnić od 0.");
            }
            if (a!=0)
            {
            if (delta < 0)
            {

                Console.WriteLine("Brak miejsc zerowych.");
            }
            if (delta == 0)
            {

                Console.WriteLine("Jedno miejsce zerowe.");
            }
            if (delta > 0)
            {

                Console.WriteLine("Dwa miejsca zerowe.");
            }
            }
        }
    }