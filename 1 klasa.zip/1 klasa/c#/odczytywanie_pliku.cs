using System;
using System.Collections.Generic;
using System.IO;
class Program {

    static void Main() {

        string content = File.ReadAllText("file.txt");
        string[] strings = content.Split(new char[] { ' ', '\t', '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries);
        int indexes = Convert.ToInt32(strings[0]);
        int index = Convert.ToInt32(strings[1]);
        int value = Convert.ToInt32(strings[2]);
        Console.WriteLine(indexes);
        int[] tab = new int[indexes];
        tab[index] = value;
        for (int i = 0; i < tab.Length; i++)
            Console.Write(tab[i] + " ");
    }
}