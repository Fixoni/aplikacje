using System;

class Program
{
 static void Main()
    {
        Console.WriteLine("Podaj swoje imie");
        string imie = Console.ReadLine();
        Console.WriteLine("Masz na imie " +imie+ " ?");
    }
}
