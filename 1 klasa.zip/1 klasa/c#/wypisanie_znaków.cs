using System;

    class Program //ASCII
    {
        static void Main()
        {
            for (int i=0;i<256;i++)
            {
                Console.WriteLine(i + " " + (char)i + " ");
            }


        }
    }