using System;
using System.IO;

namespace Strumienie
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Tworzy tablice z tekstem
            string[] text = File.ReadAllLines("plik.txt");
            //Przypisuje wartości do zmiennych
            int x = Convert.ToInt32(text[0]);
            int y = Convert.ToInt32(text[1]);
            int z = Convert.ToInt32(text[2]);
            //Tworzy tablice liczbową
            int[] tabela = new int[x];
            //Przypisuje pole z lini 2 w tekscie wartościa z lini 3
            tabela[y] = z;
            //Wypisuje Tablice
            for (int j = 0; j < x; j++)
                Console.WriteLine(tabela[j] + " ");
            //Zatrzymuje Program
            Console.ReadKey();
        }
    }
}