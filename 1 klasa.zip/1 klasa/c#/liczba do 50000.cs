Using System;

class Program
{
 static void Main()
    {
        int liczba = 0;
        while (liczba <50000)
        {
            liczba++;
            Console.Write(liczba + " ");
        }
    }
}
