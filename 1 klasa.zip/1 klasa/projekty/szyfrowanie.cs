using System;

namespace szyfrowanie
{
  class Program
  {
    static void Main(string[] args)
    {
      Console.WriteLine("wprowadz tekst");
      string tekst = Console.ReadLine();
      int klucz = 3;
      for(int i = 0; i < tekst.Length; i++)
      {
        int dane = (Char)tekst[i]+klucz;
        Console.WriteLine((char)dane);
      }


    }
  }
}