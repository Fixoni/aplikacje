<?php
//zad.1
// w pliku napisz 6 rekordow skladajacych sie z nazwiska i liczby bedacej wiekiem, pobierz dane z pliku
// wyswietl je w posatci: nazwisko, wiek:(wartosc). Znajdz najstarsza osobe (nazwisko i wiek)

/*

$tab = array();
$dane = fopen("osoby.txt","r");



for($i=1;$i<=6;$i++)
{
    $wiersz = fgets($dane);
    $tab = explode(" ",$wiersz);
    echo $tab[0]." wiek: ".$tab[1];
    echo "<br>";

    $max=0;
    
    if($tab[1]>34)
    {
        $wiekmax=$tab[1]; 
        $max=$tab[0];
    }
}
echo "Najstarsza osoba jest: ".$max." wiek: ".$wiekmax;

fclose($dane);
*/

//zad.2
/*
$miasta = array(
    array("ludność"=>array("Wrocław"=680000,"Kraków"=900000),
    array("powierzchnia"=>array("Wrocław"=>292,"Kraków"=>327)))
);
*/



/*
$miasta = array(
    "ludność"=>array("Wrocław"=680000,"Kraków"=900000),
    "powierzchnia"=>array("Wrocław"=>292,"Kraków"=>327)
);
*/
$miasta = array();

$miasta['ludnosc']['Wrocław']=680000;
$miasta['ludnosc']['Kraków']=900000;
$miasta['powierzchnia']['Wrocław']=292;
$miasta['powierzchnia']['Kraków']=327;

echo "<table border='1'>";
$a=1;
foreach($miasta as $klucz => $wartosc) {
    if($a==1)
    {
        echo "<tr>";
        echo "<th>";
        echo "</th>";
        $a++;
        foreach ($wartosc as $klucz2 => $wartosc2) {
            echo "<th>";
            echo $klucz2;
            echo "</th>";
        }
        echo "</tr>";
    }
    echo "<tr>";
    echo "<th>";
    echo $klucz;
    echo "</th>";
    foreach($wartosc as $klucz2 => $wartosc2) {
        echo "<td>";
        echo $wartosc2;
        echo "</td>";
    }
}

echo "</table>";
?>