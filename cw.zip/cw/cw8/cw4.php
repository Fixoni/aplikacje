<?php

/*
$tab=array();
$plik=fopen("plik.txt","r");
$srednia=0;

for($i=1;$i<=10;$i++)
{
    $wiersz = fgets($plik);
    $tab = explode(" ","$wiersz");
    echo $tab[0]." wiek ".$tab[1];
    $srednia = $srednia + $tab[1];
    echo "<br>";
}   
$srednia=$srednia/10;
echo "srednia wieku = ".$srednia;
$zapis = fopen("srednia.txt","w");
fwrite($zapis,"sredia arytmetyczna = ".$srednia);
*/
/*
$kraje=array();
$kraje['Europa'][0]='Polska';
$kraje['Europa'][1]='Francja';
$kraje['Europa'][2]='Francja';
$kraje['Afryka'][0]='Nigeria';
$kraje['Afryka'][1]='Tunezja';
$kraje['Afryka'][2]='Egipt';
$kraje['Azja'][0]='Japonia';
$kraje['Azja'][1]='Indie';
$kraje['Azja'][2]='Chiny';

echo "<table border='1'>";
echo "<tr>";

foreach($kraje as $klucz => $wartosc)
{
    echo "<td>".$klucz.": "."</td>";
    for($i=0;$i<=2;$i++)
    {
        echo "<th>".$wartosc[$i]." </th>";
    }
    echo "<br>";
    echo "</tr>";
}
echo "</table>";
*/
/*
$oceny=array(
    'Historia'=>array('Nowak'=>5,'Kowalski'=>3),
    'Matematyka'=>array('Nowak'=>1,'Kowalski'=>4));

    echo "<table border='1'> ";
    echo "<tr>";

    $first=true;

    foreach($oceny as $klucz => $wartosc)
    {
        if ($first) {
        $first = false;
        echo "<th></th>";
        foreach($wartosc as $nazwisko => $oce)
        {
            echo "<th>".$oce." "."</th>";
        }

        echo "<br>";
        echo "</tr>";
    }
    echo "</table>";
    */
?>