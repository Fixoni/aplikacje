z pliku pobierz dwie liczby całkowite ktore tworza zakres losowania elementow tablicy o rozmiarze 30
wyswiet pobrane liczby i elementy tablicy oraz 
srednia arytmetyczna wyslij to do pliku

<?php
$plik = fopen("plik.txt","r");
$a = fgets($plik);
$b = fgets($plik);
fclose($plik);
echo "liczby: ".$a.$b;

$tab = array();
echo "<br>";
$art = 0;
for($i = 0; $i<30; $i++) {

    $tab[$i] = rand($a,$b);
    $art = $art+$tab[$i];
    echo " ".$tab[$i];
}
$art = $art/sizeof($tab);
echo "Średnia liczb wynosi: ".$art;
$plik = fopen("tablica.txt","w");
for($i = 0; $i<sizeof($tab); $i++) {

    fwrite($plik, $tab[$i]." ");
}
fwrite($plik, "\n");
fwrite($plik, "średnia erytmetyczna ".$art);
fclose($plik);
?>