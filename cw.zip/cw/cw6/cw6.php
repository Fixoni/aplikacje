<?php
            //TABLICA ASOCJACYJNA   
/*
$tab = array("Kowalski"=>17, "Biruk"=>26, "Zabłocki"=>19,
 "Biały"=>68, "Czarny"=>72, "Żółty"=>53, "Clinton"=>33);

 $h=0;
 $suma=0;

 foreach($tab as $n => $w){

    print $n." wiek: ".$w."lat/lata";
    echo "<br>";
    $suma=$suma+$w;
    $h++;
 }
$suma=$suma/$h;
echo "średnia wieku wynosi: ".$suma;
*/
/*
$tab = array("Róża"=>"czerwony",
"Tulipan"=>"żólty",
"Fiołek"=>"fioletowy",
"Lilia"=>"biały",
"Chiacynt"=>"fioletory",
"Krokus"=>"różowy");

foreach($tab as $klucz => $wartosc) {
    
    echo $klucz. " kolor: ".$wartosc."<br>";
}
echo "Koloru czerwonego są: ";
foreach($tab as $klucz => $wartosc) {

    if($wartosc="czerwony"){

        echo " ".$klucz;
    }
}
echo "<br>";
echo "<br>";
asort($tab)
foreach($tab as $klucz => $wartosc) {

}*/

$dane = array();

$dane[0]["imie"]="Jan";
$dane[0]["nazwisko"]="Kowalski";
$dane[0]["ulica"]="Kowalewska";
$dane[1]["imie"]="Maciej";
$dane[1]["nazwisko"]="Nowak";
$dane[1]["ulica"]="Nowakowa";

echo "<table> border='1';";
echo "<tr>";
foreach($imie[0] as $klucz => $wartosc){

    foreach($wartosc as $klucz => $wartosc1) {
        
        echo "<th>".$klucz."</th>";
    }
    echo "</tr>";
}
for($i=0; $i<count($dane);$i++){

    echo "<tr>";
    foreach($dane[$i] as $k => $w){

        echo "<th>".$w."</th>";
    }
}
echo "</table>";
?>