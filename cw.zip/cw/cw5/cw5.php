<?php

$w=10;
$k=15;

$tab = array();

for($i=0; $i<$w; $i++) {

    for($j=0; $j<$k; $j++) {
        
        if($k%2!=0) {
            if($j==($k-1)/2) {
            $tab[$i][$j] = rand(0,9);
            print "<b>".$tab[$i][$j]." </b>";
            }
         else {
            $tab[$i][$j] = rand(10,99);
            print $tab[$i][$j]." ";
        }
    }else {
        if($j==$k/2-1||$j==$k/2) {
            $tab[$i][$j] = rand(0,9);
            print "<b>".$tab[$i][$j]." </b>";
        }else {
            $tab[$i][$j] = rand(10,99);
            print $tab[$i][$j]." ";
        }
    }
    }
    print "<br>";
}

$max = $tab[0][0];

for($i=0; $i<$w; $i++) {

    for($j=0; $j<$k; $j++) {
        if($tab[$i][$j]>$max) {
            $max = $tab[$i][$j];
        }
    }
}
print "najwiekszym elementem tablicy jest: ".$max;
?>