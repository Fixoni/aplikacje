<?php
/*
echo "to moj pierwszy skrypt";
echo "wstawiam obrazek o nazwie <i>1.png</i><br>";
print "<img src=\"1.png\"><br>";

$a=124;
$b=200;
echo "zmienna a".$a."<br>";
echo "zmienna b".$b."<br>";

if($a>$b)
{
    echo "";
}


$a=10;
$b=99;
$sp=0;
$snp=0;
for($a=10; $a <= $b; $a++) {

    if($a%2!=0) {
    
    print("$a \n");
    $snp+=$a;
    
    } else {
    
    print("<b>$a</b> \n");
    $sp+=$a;
    }
    
    }
    echo "suma nieparzystych to ".$snp. " ";
    echo "suma parzystych to ".$sp. " ";
*/

$c=72;
$j=$c%10;
$d=($c-$j)/10;
$e=$j*10+$d;
echo "twoja liczba to ".$c."<br>";
echo "twoja liczba po zamianie to ".$e."<br>";

?>