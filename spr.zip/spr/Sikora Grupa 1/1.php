<?php
$tab = array();

for($i=0;$i<30;$i++)
{
    if($i%2==0)
    {
        $p = rand(0,9);
        echo " ".$p." ";
    } else
    {
        $np = rand(10,99);
        echo " ".$np." ";
    }
}
$plik = fopen("zapis.txt","w");
$plik = fwrite($plik, $tab[$i]);
fclose($plik);

?>