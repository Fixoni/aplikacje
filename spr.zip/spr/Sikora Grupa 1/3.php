<?php

$tab = array();
$tab["Machnik"]=180;
$tab["Milecki"]=158;
$tab["Słowacki"]=165;
$tab["Kowalski"]=170;
$tab["Pielak"]=167;
$tab["Sulewski"]=169;
echo "<table border ='1'>";
echo "</tr>";
foreach ($tab as $key2 => $value2) {
    echo "<tr>;
    <th>".$key2." </th>";
    echo "<td>".$value2."</td>";
    
    echo "</tr>";
 }
echo "</table>";
?>