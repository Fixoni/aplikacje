<?php


$plik = fopen("tabela.txt","r");
$k = fgets($plik);
$w = fgets($plik);
$tab[$k][$w] = array();
fclose($plik);

    for($i=0;$i<$k;$i++)
    {
        for($j=0;$j<$w;$j++)
        {
            if($i%2==0 && $j%2==0)
            {
                echo " 0 ";
            } else
            {
                echo " 1 ";
            }
        }
    }

?>