<?php

$tab = array();

$tab["Polska"]["Morze"]="Tak";
$tab["Polska"]["Góry"]="Tak";
$tab["Czechy"]["Góry"]="Tak";
$tab["Czechy"]["Morze"]="Nie";
echo "<table border ='1'>";
echo "<tr>
    <th> </th>";
$a = true;
foreach ($tab as $key => $value) {
    if($a){
    foreach ($value as $key2 => $value2) {
        echo "<th>".$key2."</th>"; 
    }}
    $a = false;
}
echo "</tr>";
foreach ($tab as $key => $value) {
    echo "<tr>
    <th>".$key." </th>";
    foreach ($value as $key2 => $value2) {
    echo "<td>".$value2."</td>";
    
    }
    echo "</tr>";
 }
echo "</table>";
?>