<?php
$a=3;
switch($a)
{
    case 1:
        for($i=10;$i<=99;$i++)
        {
            echo $i." ";
        }
        break;
        case 2:
            for($i=10;$i<=99;$i++)
            {
                if($i%2==0)
                {
                    echo $i." ";
                }
            }
            break;
            case 3:
                for($i=10;$i<=99;$i++)
                {
                    if($i%2==0)
                    {
                    } else 
                    {
                        echo $i." ";
                    }
                }
                break;
                default:
                echo "nie ma takiej mozliwosci wybierz 1, 2 lub 3";
                break;
}

?>