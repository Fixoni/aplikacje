<?php
$suma = 0;
for($i=10;$i<=99;$i++)
{
    if($i%2==0)
    {
        echo $i." ";
        echo "<br>";
        if($i%4==0)
        {
            echo "<b>".$i."</b><br>";
            $suma = $suma + $i;
        } 
    }
}
echo "suma liczb podzielnych przez 4 to: ".$suma;
?>