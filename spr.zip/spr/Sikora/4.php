<?php

function srednia($a,$b,$c)
{
    $srednia=($a+$b+$c)/3;
    echo "srednia arytmetyczna liczb ".$a." ".$b." ".$c." wynosi: ".$srednia;
}

echo 
?>