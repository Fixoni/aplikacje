<?php

$kwota =2;
$suma =0;
$w = 3;

for($dni=1;$dni<=20;$dni++)
{
    $suma=$suma + $kwota;
    echo $dni." dnia kwota wynosi: ".$kwota." a suma wynosi: ".$suma."<br>";
    $kwota= $kwota + $w;
}

?>