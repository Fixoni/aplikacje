<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<form action="" method="POST">
    <label >
   <label>Podaj nazwisko:<input type="text" name="Nazwisko"></label><br>
   <label>Miejsce urodzenia:<input type="text" name="miejsce"></label><br>
 <input type="submit" value="wyslij"><br>

</form>
    
<?php

$n=$_POST['Nazwisko'];
$m=$_POST['miejsce'];
if(!isset($_POST['Nazwisko']))
{
    echo "Uzupelnij dane";
   
 
}
else{
    echo $n;
}
if(!isset($_POST['miejsce']))
{
    echo "Uzupelnij dane";
  
}
else{
    echo $m;
}

?>
</body>
</html>