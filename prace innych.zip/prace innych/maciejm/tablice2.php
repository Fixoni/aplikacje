
<!DOCTYPE html>
<html>
    <head>
        <style>
            table{
                color: rgb(200, 200, 200);
                padding: 2px;
                background-color:rgb(55, 55, 55);
                margin-bottom: 20px;
            }
            tr{
                background-color: rgb(75, 75, 75)

            }
            th{
                background-color: rgb(90, 90, 90)
            }
            tr,th{
                margin: 2px;
                padding: 5px 8px;
                text-align: center;
            }

        </style>  
    </head>
</html>

<?php
/*
$arr = Array(
    "l. mieszkańców" => array("Wrocław" => 680000, "Kraków" => 900000, "Warszawa" => 1794000),
    "powierzchnia" => array("Wrocław" => 292, "Kraków" => 327, "Warszawa" => 517),
    "Stolica państwa (tak/nie)" => array("Wrocław" => "nie", "Kraków" => "nie", "Warszawa" => "tak")
);
echo "<table>";
$first = true;
foreach($arr as $k => $v) {
    
    if ($first) {
        echo "<tr>";
        echo "<th></th>";
        foreach($v as $kk => $vv) {//wypisanie miast
            echo "<th>".$kk."</th>";
        }
        $first = false;
        echo "</tr>";
    }
    echo "<tr>";
    echo "<th>".$k."</th>";//wypisanie kluczy(lmieszkancow,powierzchnia...)
    foreach($v as $kk => $vv) {
        echo "<td>".$vv."</td>";
    }
    echo "</tr>";
}

echo "</table>";
*/


/*
Z pliku pobierz 2 liczby naturalne:
ilośc wierszy,
ilość kolumn
w tablicy dwówymiarowej

tablica tę wypełnij tak, aby na pierwszym miejscu (0,0) była liczba 2 a każda następna wartość idąc po wierszach
była o 3  większa od wartości poprzedniej
otrzymaną tablicę wyświetl na stronie
i zapisz do pliku
*/
/*
$read = fopen("nowyplik.txt", "r");
$w = intval(fgets($read));
$k = intval(fgets($read));
$arr = Array();
$c = -1;
fclose($read);

$write = fopen("output.txt", "w");
for ($i = 1; $i <= $w; $i++) {
    for ($j = 1; $j <= $k; $j++) {
        $c++;
        $arr[$i-1][$j-1] = 2 + $c*3;
        fwrite($write, $arr[$i-1][$j-1]." ");
        echo $arr[$i-1][$j-1]." ";

    }
    echo "<br>";
    fwrite($write, "\n"); 
}
*/


/*
$tab =array();
$dane = fopen("dane.txt","r");
$max=0;
$nmax="";
for($i=0;$i<=6;$i++)
{
$wiersz = fgets($dane);
$tab = explode(' ',"$wiersz");
echo  $tab[0]." wiek: ".$tab[1];

echo "<br>";

if($tab[1]>$max)
{
  $max=$tab[1];
  $nmax=$tab[0];
  
}

}
echo "Najstarsza osoba jest: ".$nmax."wiek:".$max;
fclose($dane);
*/



//zad2


/*$tab = Array(
  Array("ludnosc"=>array("Wrocław"=680000,"Kraków"=900000),
  array("Powierzchnia"=>array("Wrocław"=>292,"Kraków"=>327)))
);
*/
/*
$tab=Array();
$tab['Ludność']['Wrocław']=680000;
$tab['Ludność']['Kraków']=900000;
$tab['Powierzchnia']['Wrocław']=292;
$tab['Powierzchnia']['Kraków']=327;


echo "<table border='1'>";
$a=1;
foreach($tab as $klucz => $wartosc)
{
  if($a==1)
  {
      echo "<tr>";
      echo "<th>";
      echo "</th>";
      $a++;
      foreach($wartosc as $klucz2 => $wartosc2)//wypisanie wroclawia i krakowa
      {
        echo "<th>";
        echo $klucz2;
        echo "</th>";

      }
      echo "</tr>";
  }
  echo "<tr>";
  echo "<th>".$klucz." "."</th>";//wypisanie ludnosc,powierzchnia
  foreach($wartosc as $klucz2 =>$wartosc2)//wypisanie liczb
  {
    echo "<td>";
    echo $wartosc2;
    echo "</td>";
  }

  
}


echo "</table>";
*/


/*
Utwórz tabelę asocjacyjną gdzie kluczami są nazwy towarów natomiast wartościami ich cena.
Wypełnij tą tablicę 20 rekordami gdzie nazwy towarów będą pobrane z pliku a ceny będą liczbami losowymi
z przedziału <10:99> wypisz tą tablicę w postaci:
{nazwa} cena: {cena}zł
*/
/*
$input = fopen("towary.txt", "r");
$ceny = Array();
for ($i = 0; $i < 20; $i++) {
    $line = fgets($input);
    $ceny[$line] = rand(10, 99);
    echo $line." cena: ".$ceny[$line]."zł<br>";
}
*/









?>