<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form method="POST">
        <h1>Kwestionariusz osobowy</h1>
        Imie:<input type="text" name="imie"><br>
        Nazwisko:<input type="text" name="nazwisko"><br>
        Plec:  Kobieta<input type="radio" name="plec">
        Mezszczyzna<input type="radio" name="plec">
        <br>
        <label>Hobby:</label>
        <select name="hobby">
            <option value="komputer">Komputer</option>
            <option value="plywanie">Plywanie</option>
            <option value="czytanie">Czytanie</option>
            <option value="rysowanie">Rysowanie</option>
            <option value="pilka">Pilka nozna</option>
        </select>
        <br>
        <label>Miesce zamieszkania</label>
        <input type="text" name="miejsce" >
        <br>

</form>
    <form method="POST">
        <label>Jezyki:</label>

        
        <select name="jezyk[]" multiple="multiple">
            
            <option value="niemiecki">Niemiecki</option>
            <option value="hiszpanski">Hiszpanski</option>
            <option value="wloski">Wloski</option>
            <option value="francuzki">Francuzki</option>
            <option value="angielski">Angielski</option>
        </select>
        <br>
        <input type="submit" value="Zatwierdz">
</form>



<?php
$wybor=$_POST['jezyk']; 
$miejscowosc=$_POST['miejsce'];
echo "Wybrano jezyki:";
for($i=0;$i<count($wybor);$i++)
{
echo " ".$wybor[$i];
}
switch($miescowosc)
{
    case 1:
    echo "";
    break;
    case 2:
        echo "";
        break;
}



?>
</body>
</html>