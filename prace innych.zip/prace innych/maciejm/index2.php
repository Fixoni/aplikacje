<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Obliczanie kosztu ogrodzenia</h1>
<form action="" method="POST">
<label>Szerokosc:<input type="number" name="szer"><label><br>
<label>Dlugosc:<input type="number" name="dlu"><label><br>
<label><br>Material:  Drewno<input type="checkbox" name="d" value="drewno">Metal<input type="checkbox" name="m" value="metal"></label></br>
<label><br>Firma: <input type="checkbox" name="f" value="firma"></label></br>
<br>
<input type="submit" value="Oblicz"><br>

</form>


    <?php
    $s=$_POST['szer'];
    $dlu=$_POST['dlu'];
    $d=$_POST['d'];
    $m=$_POST['m'];
    $f=$_POST['f'];

    echo "Dlugosc ogrodzenia wynosi: ".$dlu."m, wybrano material ".$m.$d."Firma:".$f."Koszt= ".$k;
    
    if(array_key_exists("firma",$f))
    {
        echo "Tak";
    }
    else{
        echo "Nie";
    }

    $obwod=2*$d+2*$s;

    if(isset($_POST['m'],$_POST['f']))
    {
      $k=400*$obwod;
      echo "Koszt= "$k;
    }
    else{
      $k=300*$obwod;
      echo "koszt= ".$k;
    }

    if(isset($_POST['d']))
    {
      $k=250*$obwod;
      echo "koszt= ".$k;

    }
    else{
    $k=200*$obwod;
      echo "koszt= ".$k;
    }


    


    


    ?>
    
</body>
</html>