<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formularz</title>
</head>
<body>

<form action="" method="POST">
    <label >
 Podaj imie:<input type="text" name="Nazwisko"><br>
 Podaj wiek:<input type="number" name="Wiek"><br>
 <input type="submit"><br>

</form>
<?php
$n=$_POST['Nazwisko'];
$w=$_POST['Wiek'];

echo $n." witaj na mojej stronie. ";
echo "Masz: ".$w." lat.";
if($w>=18)
{
    echo " Jestes pelnoletni.";
}
else
{
    echo " Nie jestes pelnoletni.";
}







?>
</body>
</html>

<?php








?>