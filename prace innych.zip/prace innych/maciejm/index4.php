<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formularz</title>
</head>
<body>
    <h1>Obliczenie kosztu malowanego mieszkania</h1>

    <form action="" method="POST">
        <label>Podaj szerokosc pokoju:<input type="number" name="szer" ></label><br>
        <label>Podaj dlugosc pokoju:<input type="number" name="dlu" ></label><br>
        <label>Podaj wysokosc pokoju:<input type="number" name="wys" ></label><br>
        

        <label><br>Rodzaj pedzla: Waski:<input type="radio" name="waski" value="">
        Szeroki:<input type="radio" name="szeroki" value=""></label>

        <br>
         Rodzaj farby:
        <select name="farba">
             <option value="lateksowa">lateksowa</option>
             <option value="winylowa">winelowa</option>
             <option value="akrylowa">akrylowa</option>

    </select>
       
        <br>
        <input type="submit" value="Zatwierdz">
        



    </form>

<?php
error_reporting(0);
$szer=$_POST['szer'];
$dlu=$_POST['dlu'];
$wys=$_POST['wys'];
$r=$_POST['farba'];
$w=$_POST['waski'];
$s=$_POST['szeroki'];
$pedzel;


$p=$dlu*$szer+2*$szer*$wys+2*$dlu*$wys;
echo $p."m^2";
$kfa=25;
$kfw=30;
$kfl=35;

$value1=$_POST[''];
$s=0;
switch($value)
{
    case 'akrylowa':
       
        $s=$p*$kfa;
        echo "Koszt malowania farba akrylowa wynosi = ".$s;
        break;
        case 'lateksowa':
        
        $s=$p*$kfl;
        echo "Koszt malowania farba lateksowa wynosi = ".$s;
        break;
        case 'winylowa':
       
        $s=$p*$kfw;
        echo "Koszt malowania farba winylowa wynosi = ".$s;

        break;

        default:
        echo "wybrano zla opcje";
        break;

}

echo "<br>";

if(isset($_POST['waski']))
{
 $time=$p*15;
 $g=$time/60;
 echo "Czas malowania pedzlem waskim wyniesie: ".$g."godzin";
}else
{
    echo "nie podano";

}
echo "<br>";

if(isset($_POST['szeroki']))
{
    $time=$p*5;
    $g=$time/60;
    echo "Czas malowania pedzlem szerokim wyniesie:".$g."godzin";
}else{
    echo "nie podano";
}





?>
    
</body>
</html>

