#include <iostream>

using namespace std;

void sito(int n) {
    bool tab[n+1];
    for (int k = 2; k*k <= n; k++) {
        for (int i = k * 2; i <= n; i+=k) {
            tab[i] = true;
        }
    }
    for (int i = 2; i <= n; i++) {
        if (tab[i] == false) {
            cout << i << " ";
        }

    }
}

int main()
{
    sito(100000);
    return 0;
}
