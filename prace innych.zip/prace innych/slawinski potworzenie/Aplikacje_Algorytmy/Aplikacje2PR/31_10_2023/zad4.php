<?php
$tab = Array();
$tab[0]["imie"] = "Jan";
$tab[0]["nazwisko"] = "Kowalski";
$tab[0]["ulica"] = "Kowalowska";

$tab[1]["imie"] = "Anna";
$tab[1]["nazwisko"] = "Nowak";
$tab[1]["ulica"] = "Leśna";

$tab[2]["imie"] = "Robert";
$tab[2]["nazwisko"] = "Wójcik";
$tab[2]["ulica"] = "Podmokła";

echo "<table border='1'>";
echo "<tr>";
foreach($tab[0] as $k => $v) {
    echo "<th>".$k."</th>";
}
echo " </tr>";
for ($i = 0; $i < count($tab); $i++) {
    echo "<tr>";
    foreach($tab[$i] as $k => $v) {
        echo "<td>".$v."</td>";
    }
    echo "</tr>";
}
echo "</table>";

?>