<?php
$tab = Array();
$tab["Przylaszczka pospolita"] = "fioletowy";
$tab["Stokrotka"] = "biały";
$tab["Dumchawiec"] = "biały";
$tab["Mlecz"] = "żółty";
$tab["Róża"] = "czerwony";
$tab["Tulipan"] = "różowy";
$tab["Krokus"] = "niebieski";

foreach($tab as $k => $v) {
    echo $k." kolor: ".$v."<br>";
}
echo "<br><br>Koloru czerwonego są:<br>";

foreach($tab as $k => $v) {
    if ($v == "czerwony")
        echo $k."<br>";
}
echo "<br><br>";
asort($tab);

foreach($tab as $k => $v) {
    echo $k." kolor: ".$v."<br>";
}
?>