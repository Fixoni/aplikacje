<?php
    function GenerateArray($m, $n) {
        $s = 0;
        $tab = Array();
        for ($i = 0; $i < $m; $i++) {
            for ($j = 0; $j < $n; $j++) {
                $tab[$i][$j] = $i * $j;
                echo $tab[$i][$j]." ";
                if ($i == $j) {
                    $s += $tab[$i][$j];
                }
                
            }
            echo "<br>";
        }

        echo "Suma liczb po przekątnej lewo-prawo: ".$s;
        echo "<br>";
        echo "<br>";

        $s = 0;
        $tab2 = Array();
        for ($i = 0; $i < $m; $i++) {
            for ($j = 0; $j < $n; $j++) {
                $tab2[$j][$i] = $tab[sizeof($tab)-$i-1][$j];
            }
            
        
        }

        for ($i = 0; $i < $m; $i++) {
            for ($j = 0; $j < $n; $j++) {
                if ($i == $j) {
                    $s += $tab2[$i][$j];
                }
                
            }
            echo "<br>";
        }


        echo "<br><br>Suma liczb po przekątnej prawo-lewo: ".$s;
    }


    GenerateArray(5, 5);
?>