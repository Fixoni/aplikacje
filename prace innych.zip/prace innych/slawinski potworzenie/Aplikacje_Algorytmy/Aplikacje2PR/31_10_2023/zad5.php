z pliku pobierz 2 liczby całkowite które stanowią zakres losowania elementów tablicy o rozmiarze 30
Wyświetl pobrane liczby, elementy tablicy i elementy te wraz z ich średnią artytmetyczną wyślij do pliku
plik dane i tablica

<?php
    if (file_exists("dane.txt")) {
        echo "Otwieranie pliku<br>";
        $dane = fopen("dane.txt", "r") or die("Wystąpił błąd przy otwieraniu pliku!<br>");
        if ($dane) {
            $n1 = intval(fgets($dane));
            $n2 = intval(fgets($dane));
            echo("Liczba 1: ".$n1."<br>");
            echo("Liczba 2: ".$n2."<br>");
            fclose($dane);
            if (!file_exists("tablica.txt")) {
                touch("tablica.txt");
            }
            $toFile = "";
            $tablica = fopen("tablica.txt", 'w');
            $tab[] = Array();
            $s = 0;
            for ($i = 0; $i < 30; $i++) {
                $tab[$i] = rand($n1, $n2);
                echo $tab[$i]."<br>";
                $toFile = $toFile.$tab[$i]." ";
                $s += $tab[$i];

            }
            $toFile = $toFile."\nŚrednia arytmetyczna: ".($s/30);
            fwrite($tablica, $toFile);
            fclose($tablica);
        }
    } else {
        echo "Plik dane.txt nie istnieje!<br>";
    }
    
?>