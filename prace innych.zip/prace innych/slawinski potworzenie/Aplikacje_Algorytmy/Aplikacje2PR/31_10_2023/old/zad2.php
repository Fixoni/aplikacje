<?php
$tab = Array();

$w = 10;
$k = 7;
$s = 0;
for ($i = 0; $i < $w; $i++) {
    for ($j = 0; $j < $k; $j++) {
        $tab[$k][$w] = rand(10, 99);
        $s += $tab[$k][$w];
        echo $tab[$k][$w]." ";
    }
    echo "<br>";
}

echo "Suma: " . $s;



?>