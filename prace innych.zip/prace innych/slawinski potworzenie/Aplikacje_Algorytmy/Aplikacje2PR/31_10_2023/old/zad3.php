<?php
$tab = Array();

$w = 5;
$k = 10;
for ($i = 0; $i < $w; $i++) {
    for ($j = 0; $j < $k; $j++) {
        if (($i + $j) % 2 == 0) {
            $tab[$i][$j] = "X";
        } else {
            $tab[$i][$j] = "O";
        }
        echo $tab[$i][$j]." ";
    }
    echo "<br>";
}




?>