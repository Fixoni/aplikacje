<?php
$tab = Array();

$w = 11;
$s = 0;
for ($i = 0; $i < $w; $i++) {
    for ($j = 0; $j < $w; $j++) {
        $tab[$i][$j] = 0;
    }
}
for ($i = 0; $i < $w; $i++) {
    $tab[$i][$i] = 1;
    $tab[$w-$i-1][$i] = 1;
}
echo "<br>";
for ($i = 0; $i < $w; $i++) {
    for ($j = 0; $j < $w; $j++) {
        echo $tab[$i][$j]." ";
    }
    echo "<br>";
}

echo "<br>";
echo "<br>";
echo "<br>";
$tab = Array();

for ($i = 0; $i < $w; $i++) {
    for ($j = 0; $j < $w; $j++) {
        if ($i == $j || $i+$j = $w - 1) {
            $tab[$i][$j] = 1;
        } else {
            $tab[$i][$j] = 0;
        }
        echo $tab[$i][$j]." ";

    }
    echo "<br>";
}


?>