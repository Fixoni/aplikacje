<?php
$tab = Array();

$w = 30;
$k = 10;
for ($i = 0; $i < $w; $i++) {
    if ($i %3 == 0) {
        $tab[$i] = 7;
    }
    else {
        $tab[$i] = 0;
    }
    echo $tab[$i]." ";
}




?>