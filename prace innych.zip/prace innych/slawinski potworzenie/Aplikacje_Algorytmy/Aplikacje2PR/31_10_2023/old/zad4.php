<?php
$tab = Array();

$w = 8;
$k = 12;
for ($i = 0; $i < $w; $i++) {
    for ($j = 0; $j < $k; $j++) {
        $tab[$i][$j] = rand(10, 99);
    }
}
//sort($tab);
for ($i = 0; $i < $w; $i++) {
    for ($j = 0; $j < $k; $j++) {
        echo $tab[$i][$j]." ";
    }
    echo "<br>";
}
echo "<br>";
echo "<br>";
echo "<br>";

for ($i = 0; $i < $w; $i++) {
    sort($tab[$i]);
    for ($j = 0; $j < $k; $j++) {
        echo $tab[$i][$j]." ";
    }
    echo "<br>";
}


/*$w = 20;
$k = 10;
for ($i = 0; $i < $w; $i++) {
    $tab[$i] = rand(100, 999);
}
rsort($tab);
for ($i = 0; $i < $w; $i++) {
    echo $tab[$i]. " ";
}
echo "<br>";
print_r($tab);*/
/*

sort($nazwa) - rosnąco
rsort($nazwa) - malejąco
print_r($nazwa) - wyświetlenie informacji o tablicy
*/

?>