<?php

$w = 8;
$k = 12;
for ($i = 0; $i < $w; $i++) {
    for ($j = 0; $j < $k; $j++) {
        $tab[$i][$j] = rand(10, 99);
    }
}
//sort($tab);
for ($i = 0; $i < $w; $i++) {
    for ($j = 0; $j < $k; $j++) {
        echo $tab[$i][$j]." ";
    }
    echo "<br>";
}
echo "<br>";
echo "<br>";
echo "<br>";


$tab2 = Array();
for ($i = 0; $i < $w; $i++) {
    for ($j = 0; $j < $k; $j++) {
        $tab2[$j][$i] = $tab[$i][$j];
    }
    

}
for ($i = 0; $i < $k; $i++) {
    sort($tab2[$i]);
    /*for ($j = 0; $j < $w; $j++) {
        echo $tab2[$i][$j]." ";
    }*/
    echo "<br>";
}

$tab = Array();
for ($i = 0; $i < $k; $i++) {
    for ($j = 0; $j < $w; $j++) {
        $tab[$j][$i] = $tab2[$i][$j];
    }
    

}

echo "<br>";
echo "<br>";
echo "<br>";

for ($i = 0; $i < $w; $i++) {
    //sort($tab[$i]);
    for ($j = 0; $j < $k; $j++) {
        echo $tab[$i][$j]." ";
    }
    echo "<br>";
}
?>