tablicę dwuwymiarową gdzie ilość wierszy i kolumn pobieramy z pliku wypełnij tak
aby środkowy wiersz lub dwa środkowe wiersze stanowiły liczby 1 a pozaostałe 0

Wyświetl tą tablicę i zapisz ją do pliku

<?php
    if (file_exists("array.txt")) {
        echo "Otwieranie pliku<br>";
        $dane = fopen("array.txt", "r") or die("Wystąpił błąd przy otwieraniu pliku!<br>");
        if ($dane) {
            $n1 = intval(fgets($dane));
            $n2 = intval(fgets($dane));
            fclose($dane);



            if (!file_exists("tablica.txt")) {
                touch("tablica.txt");
            }
            $toFile = "";
            $tablica = fopen("tablica.txt", 'w');
            $tab[] = Array();
            $s = 0;

            for ($i = 0; $i < $n1; $i++) {
                for ($j = 0; $j < $n2; $j++) {
                    if (($n1 % 2 == 1 && $i == $n1/2) || ($n1 % 2 == 0 && ($i + 0.5 == $n1 / 2 || $i - 0.5 == $n1 / 2))) {
                        $tab[$i][$j] = 1;
                        
                    } else {
                        $tab[$i][$j] = 0;
                    }
                    echo $tab[$i][$j]." ";
                    fwrite($tablica, $tab[$i][$j]." ");

                }
                fwrite($tablica, "\n");
                echo "<br>";

            }
            
            fclose($tablica);
        }
    } else {
        echo "Plik dane.txt nie istnieje!<br>";
    }
    
?>