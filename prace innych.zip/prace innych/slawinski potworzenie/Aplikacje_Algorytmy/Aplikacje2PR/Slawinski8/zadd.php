tablicę dwuwymiarową gdzie ilość wierszy i kolumn pobieramy z pliku wypełnij tak
aby środkowy wiersz lub dwa środkowe wiersze stanowiły liczby 1 a pozaostałe 0

Wyświetl tą tablicę i zapisz ją do pliku