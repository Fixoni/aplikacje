<!DOCTYPE html>
<html lang = "pl">
    <head>
    </head>

    <body>
        <h1>Kwiaciarnia</h1>
        <form method="post">
            Wybierz kwiat:<br>
            <select name = "kwiat">
                <?php
                    $file = fopen("dane2.txt", 'r');

                    while ($row = fgets($file)) {
                        echo '<option value = "'.$row.'">'.explode(";", $row)[0].'</option>';
                    }
                    fclose($file);
                ?>
            </select><br>
            Ilość sztuk: <input type = "number" name = "ilosc" placeholder="1"><br>
            Przyozdobienie: <input type="checkbox" name = "przyodzobienie"><br>
            <button type="submit" name = "submit">Zatwierdź</button>
            <br>
        </form>
    </body>
</html>


<?php
    if (isset($_POST["submit"])) {
        $ceny = Array(
            "Stokrotka" => 10,
            "Róża" => 15,
            "Mlecz" => 9,
            "Żonkil" => 16,
            "Krokus" => 21,
            "Forsycja" => 7
        );
        $ilosc = ($_POST["ilosc"] == "" ? 1 : $_POST["ilosc"]);
        echo "Kupiono: ".explode(";", $_POST["kwiat"])[0];
        echo ", sztuk ".$ilosc.", kolor: " .explode(";", $_POST["kwiat"])[1]. "<br>";
        if (isset($_POST["przyodzobienie"])) {
            echo "Przyozdobienie: TAK<br>";
        } else {
            echo "Przyozdobienie: NIE<br>";
        }
        $cena = (isset($_POST["przyodzobienie"])) ? 20 : 0;
        $cena += $ceny[explode(";", $_POST["kwiat"])[0]]*$ilosc;
        echo "Koszt pojedynczego kwiatka: ".$ceny[explode(";", $_POST["kwiat"])[0]]."<br>";
        echo "Koszt: ".$cena."<br>";
        
    }
?>