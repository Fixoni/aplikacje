<!DOCTYPE html>
<html lang = "pl">
    <head>
    </head>

    <body>
        <form method="post">
            Podaj nazwisko: <input type="text" name = "name"><br>

            Zawód, który wykonujesz:<br>
            <select name = "zawod">
                <?php
                    $file = fopen("dane.txt", 'r');

                    while ($row = fgets($file)) {
                        echo '<option>'.$row.'</option>';
                    }
                    fclose($file);
                ?>
            </select><br>
            <button type="submit" name = "submit">Wyślij</button>
            <br>
        </form>
    </body>
</html>


<?php
    if (isset($_POST["submit"])) {
        if ($_POST["name"] == "") {
            echo "Nie wprowadzono nazwiska !";
        } else {
            echo $_POST["name"].", wykonuje zawód: ".$_POST["zawod"];
            $file = fopen("wyniki.txt", 'a');
            fwrite($file, $_POST["name"]."   ".$_POST["zawod"]."\n");
            fclose($file);
        }
        
    }
?>