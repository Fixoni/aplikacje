<!DOCTYPE html>
<html lang = "pl">
    <head>
    </head>

    <body>
        <h1>Dane nauczyciela</h1>
        <form method="post">
            Nazwisko: <input type="text" name = "name"><br>
            Nauczane przedmioty:<br>
            <select name = "przedmioty[]" multiple>
                <?php
                    $file = fopen("dane3.txt", 'r');

                    while ($row = fgets($file)) {
                        echo '<option>'.$row.'</option>';
                    }
                    fclose($file);
                ?>
            </select><br>
            Stopień awansu: <input type = "radio" name = "stopien" value = "stażysta" checked>stażysta
             <input type = "radio" name = "stopien" value = "mianowany">mianowany
             <input type = "radio" name = "stopien" value = "dyplomowany">dyplomowany
            <br>
            Staż pracy: <input type="number" name = "staz" placeholder = "0"><br>
            <button type="submit" name = "submit">Wyznacz pensję</button>
            <br>
        </form>
    </body>
</html>


<?php
    if (isset($_POST["submit"])) {
        if ($_POST["name"] != "") {
            $pensjeBazowe = Array("stażysta" => 3000, "mianowany" => 3500, "dyplomowany" => 4000);
        
            $staz = ($_POST["staz"] == "") ? 0 : $_POST["staz"];
            $pensja = $pensjeBazowe[$_POST["stopien"]] + $staz*100;

            echo $_POST["name"].": ";
            if (isset($_POST["przedmioty"])) {
                $arr =$_POST["przedmioty"];
                foreach ($arr as $k => $v) {
                    echo $v.", ";
                }
                
            }
            
            echo "<br>";
            echo "Stopień: ".$_POST["stopien"]."<br>";
            echo "Staż pracy: ".$staz."<br>";
            echo "Pensja: ".$pensja."zł<br>";
        } else {
            echo "Nie podano nazwiska!<br>";
        }
        
    }
?>