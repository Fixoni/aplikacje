<!DOCTYPE html>



<html lang="pl">

    <head>
        <meta charset="utf-8">
        <link rel="stylesheet" href="style.css">
    </head>

    <body>
        <form method = "post">
            Obliczanie kosztu ogrodzenia:<br>
            Szerokość(m):
            <input type="number" name = "width" require>
            <br>
            Długość(m):
            <input type="number" name = "length" require>
            <br>
            Materiał:

             metal 
            <input type="radio" id="radio1" name="material" value="metal">
             drewno 
            <input type="radio" id="radio2" name="material" value="drewno">
            <br>
            Firma:
            <input type="checkbox" name = "company">
            <br>
            <button type="submit" name="Submit">Oblicz</button>
        </form>

        <?php
            if (array_key_exists("Submit", $_POST)) {
                $m = 1;
                $len = $_POST["length"] * 2 + $_POST["width"] * 2;
                echo "Długość ogrodzenia: ".$len."m <br>";
                
                $price = 0;
                if (array_key_exists("material", $_POST) && $_POST["material"] == "metal") {
                    $price = 300;
                    echo "Wybrano materiał: metal<br>";
                    if (array_key_exists("company", $_POST) && $_POST["company"] == "checked") {
                        $price += 400;
                        echo "Firma: TAK<br>";
                    } else {
                        echo "Firma: NIE<br>";
                    }
                } else {
                    $price = 250;
                    echo "Wybrano materiał: drewno<br>";
                    if (array_key_exists("company", $_POST) && $_POST["company"] == "checked") {
                        echo "Firma: TAK<br>";
                        $price += 200;
                    } else {
                        echo "Firma: NIE<br>";
                    }
                }

                
                
                echo "Koszt: ".($price*$len)."zł";
            }

        ?>
    </body>

</html>

