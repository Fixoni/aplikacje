<!DOCTYPE html>



<html lang="pl">

    <head>
        <meta charset="utf-8">
        <link rel="stylesheet" href="style.css">
    </head>

    <body>
        <form method = "post">
            Podaj nazwisko:
            <input type="text" name = "lastname">
            <br>
            Miejsce urodzenia:
            <input type="text" name = "birthplace">
            <br>
            <button type="submit" name="Submit">Wyślij</button>
        </form>

        <?php
            if (array_key_exists("Submit", $_POST)) {
                if (!empty($_POST["birthplace"]) && !empty($_POST["lastname"])) {
                    echo "Nazwisko: ".$_POST["lastname"]."<br>Miejsce urodzenia: ".$_POST["birthplace"]."<br>";
                } else {
                    
                    echo "<span style = 'color:#F00;'>Uzupełnij dane!</span>";
                }

                
                
                
            }

        ?>
    </body>

</html>

