<!DOCTYPE html>

<?php
    if (array_key_exists("Submit", $_POST)) {
        $n = $_POST["lastname"];
        $w = $_POST["age"];
        echo $n.", Witaj na mojej stronie!<br>";
        echo "Masz ".$w." lat. ";
        if ($w >= 18) {
            echo "Jesteś pełnoletni.";
        } else {
            echo "Jesteś nieletni.<br><br>";
        }
    }

?>

<html lang="pl">

    <head>
        <meta charset="utf-8">
        <link rel="stylesheet" href="style.css">
    </head>

    <body>
        <form method = "post">
            Podaj nazwisko:
            <input type="textbox" name = "lastname">
            <br>
            Podaj wiek:
            <input type="number" name = "age">
            <br>
            <button type="submit" name="Submit">Wyślij</button>
        </form>
    </body>

</html>

