<?php
/*
Z pliku pobierz 2 liczby naturalne:
ilośc wierszy,
ilość kolumn
w tablicy dwówymiarowej

tablica tę wypełnij tak, aby na pierwszym miejscu (0,0) była liczba 2 a każda następna wartość idąc po wierszach
była o 3  większa od wartości poprzedniej
otrzymaną tablicę wyświetl na stronie
i zapisz do pliku
*/

$read = fopen("inputData.txt", "r");
$w = intval(fgets($read));
$k = intval(fgets($read));
$arr = Array();
$c = -1;
fclose($read);

$write = fopen("output.txt", "w");
for ($i = 1; $i <= $w; $i++) {
    for ($j = 1; $j <= $k; $j++) {
        $c++;
        $arr[$i-1][$j-1] = 2 + $c*3;
        fwrite($write, $arr[$i-1][$j-1]." ");
        echo $arr[$i-1][$j-1]." ";

    }
    echo "<br>";
    fwrite($write, "\n");
}
?>