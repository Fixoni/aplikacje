
<!DOCTYPE html>
<html>
    <head>
        <style>
            table{
                color: rgb(200, 200, 200);
                padding: 2px;
                background-color:rgb(55, 55, 55);
                margin-bottom: 20px;
            }
            tr{
                background-color: rgb(75, 75, 75)

            }
            th{
                background-color: rgb(90, 90, 90)
            }
            tr,th{
                margin: 2px;
                padding: 5px 8px;
                text-align: center;
            }

        </style>  
    </head>
</html>
<?php
/*

*/

$arr = Array(
    "l. mieszkańców" => array("Wrocław" => 680000, "Kraków" => 900000, "Warszawa" => 1794000),
    "powierzchnia" => array("Wrocław" => 292, "Kraków" => 327, "Warszawa" => 517),
    "Stolica państwa (tak/nie)" => array("Wrocław" => "nie", "Kraków" => "nie", "Warszawa" => "tak")
);
echo "<table>";
$first = true;
foreach($arr as $k => $v) {
    
    if ($first) {
        echo "<tr>";
        echo "<th></th>";
        foreach($v as $kk => $vv) {
            echo "<th>".$kk."</th>";
        }
        $first = false;
        echo "</tr>";
    }
    echo "<tr>";
    echo "<th>".$k."</th>";
    foreach($v as $kk => $vv) {
        echo "<td>".$vv."</td>";
    }
    echo "</tr>";
}

echo "</table>";

?>