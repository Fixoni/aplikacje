
<!DOCTYPE html>
<html>
    <head>
        <style>
            table{
                color: rgb(200, 200, 200);
                padding: 2px;
                background-color:rgb(55, 55, 55);
                margin-bottom: 20px;
            }
            tr{
                background-color: rgb(75, 75, 75)

            }
            th{
                background-color: rgb(90, 90, 90)
            }
            tr,th{
                margin: 2px;
                padding: 5px 8px;
                text-align: center;
            }

        </style>  
    </head>
</html>
<?php
    /*
    W pliku umieść 10 rekordów składających się z nazwiska i z liczby oznaczającej wiek.
    Pobierz dane z pliku, wyświetl je na stronie w postaci:
    {Nazwisko} wiek: {wiek}
    Wyznacz średnią wieku wypisanych osób.


    //explode(";", $string)
    //implode(";", $table)

    //split
    */

    $kraje = Array(
        'Europa' => array("Polska", "Niemcy", "Hiszpania"),
        'Azja' => array("Korea południowa", "Japonia", "Chiny"),
        'Afryka' => array("RPA", "Kongo", "Nigeria"),
        'Ameryka Południowa' => array("Chile", "Brazylia", "Argentyna")
        
    );
    echo '<table>';
    
    
    //$c = 0;
    foreach($kraje as $k => $v) {
        /*if ($c == 0) {
            echo "<tr>";
            echo "<th></th>";
            for ($i = 0; $i < sizeof($v); $i++) {
                echo "<th>".$i."</th>";
            }
            echo "</tr>"; 
        }*/
        echo "<tr>";
        echo "<th>".$k."</th>";
        for ($i = 0; $i < sizeof($v); $i++) {
            echo "<td>".$v[$i]."</td>";
        }
        echo "</tr>";
        //$c++;
    }
    echo "</table>";
    

    $grades = Array(
        'Historia' => array("Nowak" => 5, "Kowalski" => 3, "Nowacki" => 2, "Kowal" => 6),
        'Matematyka' => array("Nowak" => 1, "Kowalski" => 4, "Nowacki" => 1, "Kowal" => 5),
        'Biologia' => array("Nowak" => 4, "Kowalski" => 3, "Nowacki" => 2, "Kowal" => 3),
        'Geografia' => array("Nowak" => 2, "Kowalski" => 1, "Nowacki" => 1, "Kowal" => 2)
        
    );

    echo '<table>';
    
    
    $c = true;
    foreach($grades as $k => $v) {
        if ($c) {
            $c = false;
            echo "<tr>";
            echo "<th></th>";
            foreach($v as $kk => $vv) {
                echo "<td>".$kk."</td>";
            }
            echo "</tr>";
            
        }
        echo "<tr>";
        echo "<th>".$k."</th>";
        foreach($v as $kk => $vv) {
            echo "<td>".$vv."</td>";
        }
        echo "</tr>";
    }
    echo "</table>";
?>