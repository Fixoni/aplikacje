
<?php
    /*
    W pliku umieść 10 rekordów składających się z nazwiska i z liczby oznaczającej wiek.
    Pobierz dane z pliku, wyświetl je na stronie w postaci:
    {Nazwisko} wiek: {wiek}
    Wyznacz średnią wieku wypisanych osób.
    */
    //explode(";", $string)
    $dane = fopen("db.txt", "r") or die("Wystąpił błąd przy otwieraniu pliku!<br>");
    if ($dane) {

        $s = 0;
        
        for ($i = 0; $i < 10; $i++) {
            $line = fgets($dane);
            $data = explode(";", $line);
            echo $data[0]." wiek: ".$data[1]."<br>";
            $s += intval($data[1]);
        }
        echo "średnia wieku: ".($s/10);
        fclose($dane);
    }
    
?>