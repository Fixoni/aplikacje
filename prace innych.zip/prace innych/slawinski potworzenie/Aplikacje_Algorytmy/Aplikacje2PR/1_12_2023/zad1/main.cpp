#include <iostream>
#include <cmath>
#include <time.h>
#include <fstream>

using namespace std;

void bubbleSort(int tab[], int n) {
    int temp;
    for (int i = 1; i < n; i++) {
        for (int j = 0; j < n-i; j++) {
            if (tab[j] > tab[j+1]) {
                temp = tab[j];
                tab[j] = tab[j+1];
                tab[j+1] = temp;
            }
        }
    }
}

int main()
{
    srand(time(NULL));
    fstream file;
    file.open("plik.txt", ios::out);
    cout << "Wprowad� rozmiar tablicy" << endl;
    int n;
    cin>>n;
    int tab[n];
    for (int i = 0; i < n; i++) {
        tab[i] = rand()%(100-1+1)+1;
        cout << tab[i]<<" ";

    }
    bubbleSort(tab, n);
    cout << endl;
    for (int i = 0; i < n; i++) {
        cout <<tab[i]<< " ";
        file << tab[i]<<" ";
    }
    file.close();

    return 0;
}
