<!DOCTYPE html> 
<html lang="pl">
    <head>
        <meta charset = "utf8">
        <link rel = "stylesheet" href="style.css">
    </head>

    <body>
        <div style = "text-align: center;"><h2>Jakich języków obcych się uczysz ?</h2></div>
        <main>
            
            <section>
                <form method="post">
                    <i>Wybierz:</i> <br><br>
                    <select name="langs[]" multiple style = 'height: 300px; width: 200px;'>
                        <option value="Polski">Polski</option>
                        <option value="Angielski">Angielski</option>
                        <option value="Niemiecki">Niemiecki</option>
                        <option value="Hiszpański">Hiszpański</option>
                        <option value="Włoski">Włoski</option>
                        <option value="Japoński">Japoński</option>
                    </select>
                    <br>
                    <input type="submit" value = "Wypisz" name = "oblicz"> 
                </form>
            </section>

        </main>
        <div style = "text-align: center">
            <br>
            <?php 
            
                if (isset($_POST["oblicz"])) {
                    $langs = $_POST["langs"];
                    echo "Wybrano języki:<br><br>";
                    for ($i = 0; $i < sizeof($langs); $i++) {
                        echo $langs[$i]."<br>";
                    }
                    
                }

            ?>
            </div>
    </body>

</html>

<?php



?>