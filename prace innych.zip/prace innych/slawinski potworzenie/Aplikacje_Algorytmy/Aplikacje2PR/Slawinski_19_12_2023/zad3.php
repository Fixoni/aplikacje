<!DOCTYPE html> 
<html lang="pl">
    <head>
        <meta charset = "utf8">
        <link rel = "stylesheet" href="style.css">
    </head>

    <body>
        <div style = "text-align: center;"><h2>Kwestionariusz osobowy</h2></div>
        <main>
            
            <section>
                <form method="post">
                    
                    <i>Nazwisko:</i> <input type = "text" name = "lastname"><br>
                    <br>
                    <i>Imię:</i> <input type = "text" name = "firstname"><br>
                    <br>
                    <i>Płeć:</i> 
                    mężczyzna <input type = "radio" id = "radio1" name = "gender" value = "mężczyzna" checked>
                    kobieta <input type = "radio" id = "radio2" name = "gender" value = "kobieta">
                    <br>
                    <i>Hobby:</i> <br><br>
                    <select name="langs[]" multiple style = 'height: 150px; width: 200px;'>
                        <option>Programowanie</option>
                        <option>Informatyka</option>
                        <option>Sport</option>
                        <option>Gra na instrumencie</option>
                        <option>Produkcja muzyki</option>
                    </select>
                    <br>
                    
                    
                   <b> <i>Miejsce zamieszkania:</i></b><br>
                    Mała miejscowość (<5 tys os) <input type = "radio" id = "radio1" name = "town" value = "małej miejscowości" checked><br>
                    Średnia miejscowość (5-20 tys os) <input type = "radio" id = "radio2" name = "town" value = "średniej miejscowości"><br>
                    Duża miejscowość (20< tys os)  <input type = "radio" id = "radio3" name = "town" value = "dużej miejscowości"><br>
                    <br>
                    <input type="submit" value = "Wypisz" name = "oblicz"> 
                </form>
            </section>

        </main>
        <div style = "text-align: center">
            <br>
            <?php 
            
                if (isset($_POST["oblicz"])) {
                    $langs = $_POST["langs"];
                    echo $_POST["firstname"]." ".$_POST["lastname"]."<br>".$_POST["gender"].",<br>"."Mieszka w ".$_POST["town"].".<br>Hobby:<br><br>";
                    $s = 0;
                    for ($i = 0; $i < sizeof($langs); $i++) {
                        echo $langs[$i]."<br>";
                        $s++;
                    }
                    echo "<br>Zaznaczono ".$s." opcji z hobby";
                    
                }

            ?>
            </div>
    </body>

</html>

<?php



?>