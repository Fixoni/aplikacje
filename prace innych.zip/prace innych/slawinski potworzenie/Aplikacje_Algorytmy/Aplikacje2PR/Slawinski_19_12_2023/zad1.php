<!DOCTYPE html> 
<html lang="pl">
    <head>
        <meta charset = "utf8">
        <link rel = "stylesheet" href="style.css">
    </head>

    <body>
        <div style = "text-align: center;"><h2>Obliczanie ceny malowania mieszkania</h2></div>
        <main>
            
            <section>
                <form method="post">
                    <i>Podaj szerokość:</i> <input type = "number" name = "width"><br>
                    <br>
                    <i>Podaj wysokość:</i> <input type = "number" name = "height"><br>
                    <br>
                    <i>Podaj długość:</i> <input type = "number" name = "length"><br>
                    <br>

                    <i>Rodzaj pędzla:</i> 
                    Wąski: <input type = "radio" id = "radio1" name = "brush" value = "wąski">
                        Szeroki: <input type = "radio" id = "radio2" name = "brush" value = "szeroki" checked>
                    <br>

                    Rodzaj farby: 
                    <select name = "paint">
                        <option value = "lateksowa">lateksowa</option>
                        <option value = "akrylowa">akrylowa</option>
                        <option value = "winylowa">winylowa</option>
                    </select>
                    <br>

                    <input type="submit" value = "Oblicz" name = "oblicz">
                </form>
            </section>

        </main>
        <div style = "text-align: center">
            <br>
            <?php
                if (isset($_POST["oblicz"])) {
                    $b = $_POST["width"];
                    $c = $_POST["height"];
                    $a = $_POST["length"];
                    if ($a == "" || $b == "" || $c == "" || $a <= 0 || $b <= 0 || $c <= 0) {
                        echo "Proszę podać poprawne wymiary pokoju";
                    } else {
                        $p = $a*$b + 2*$a*$c + 2*$b*$c;
                        $br = 5;
                        if ($_POST["brush"] == "wąski") {
                            $br = 15;
                        }
                        $paintPrice = 25;
                        if ($_POST["paint"] == "winylowa") {
                            $paintPrice = 30;
                        } else if ($_POST["paint"] == "lateksowa") {
                           $paintPrice = 35; 
                        }
                        $koszt_farby = $p * $paintPrice;
                        $time = $p * $br;
                        $mins = $time % 60;
                        $hours = ($time - $mins) / 60;

                        echo "Wybrano farbę: ".$_POST["paint"]."<br>";
                        echo "Wybrano pędzel: ".$_POST["brush"]."<br>";
                        echo "<br>Powierzchnia: ".$p."m2<br>";
                        echo "Koszt farby: ".$koszt_farby."zł<br>";
                        echo "Czas malowania: ".$hours." godzin ".$mins." minut<br>";
                    }
                    
                }
            ?>
            </div>
    </body>

</html>

<?php



?>