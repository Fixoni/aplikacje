<!DOCTYPE html> 
<html lang="pl">
    <head>
        <meta charset = "utf8">
        <link rel = "stylesheet" href="style.css">
    </head>

    <body>
    <div class = "baner">
    <a  href="index.php"><img src="baner.jpg"></a>
        </div>
        <div style = "text-align: center;"><h1>PROSTE DZIAŁANIA</h1></div>
        <main>
            
            <section>
                <form>
                    <i>Podaj pierwszą liczbę:</i> <input type = "number" class="number" name = "num1"><br>
                    <br>
                    <i>Podaj drugą liczbę:</i> <input type = "number" class="number" name = "num2"><br>
                    <br>
                    <div class = "buttonContainer">
                        <input type="submit" value = "DODAWANIE" name = "oblicz" style = "margin-right: 20px">
                        <input type="submit" value = "ODEJMOWANIE" name = "oblicz" style = "margin-right: 20px">
                        <input type="submit" value = "MNOZENIE" name = "oblicz" style = "margin-right: 20px">
                        <input type="submit" value = "DZIELENIE" name = "oblicz">
                    </div>
                </form>
            </section>

        </main>
        <div style = "text-align: center">
            <br>
            <?php
                if (isset($_GET["oblicz"])) {
                    $n1 = $_GET["num1"];
                    $n2 = $_GET["num2"];
                    if ($n1 == "" || $n2 == "") {
                        echo "Proszę uzupełnić obie liczby";
                    } else {
                        if ($_GET["oblicz"] == "DODAWANIE") {
                            echo "Wynik: ".($n1+$n2);
                        } else if ($_GET["oblicz"] == "ODEJMOWANIE") {
                            echo "Wynik: ".($n1-$n2);
                        } else if ($_GET["oblicz"] == "MNOZENIE") {
                            echo "Wynik: ".($n1*$n2);
                        } else {
                            if ($n2 == 0) {
                                echo "Nie wolno dzielić przez zero. ";
                            } else {
                                echo "Wynik: ".($n1/$n2);
                            }
                        }
                    }
                }
            ?>
            </div>
    </body>

</html>

<?php



?>