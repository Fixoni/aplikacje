<!DOCTYPE html> 
<html lang="pl">
    <head>
        <meta charset = "utf8">
        <link rel = "stylesheet" href="style.css">
    </head>

    <body>
        <div class = "baner">
        <a  href="index.php"><img src="baner.jpg"></a>
        </div>
        <main>
            <section style="width:30%">
                Menu<br>
                <a href="strona1.php">- proste działania</a><br>
                <a href="strona2.php">- potęgowanie</a><br>
            </section>
            <section>
                <i>Znajdujesz się na stronie o tematyce matematycznej.<br>
                Mój PESEL to: 27270705060</i>
            </section>
        </main>
    </body>

</html>

<?php



?>