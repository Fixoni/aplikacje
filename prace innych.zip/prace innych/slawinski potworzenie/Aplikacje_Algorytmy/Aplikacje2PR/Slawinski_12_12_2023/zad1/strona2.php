<!DOCTYPE html> 
<html lang="pl">
    <head>
        <meta charset = "utf8">
        <link rel = "stylesheet" href="style.css">
    </head>

    <body>
    <div class = "baner">
    <a  href="index.php"><img src="baner.jpg"></a>
        </div>
        <div style = "text-align: center;"><h1>POTĘGOWANIE</h1></div>
        <main>
            
            <section>
                <form>
                    <i>Podaj podstawę potęgi:</i> <input type = "number" class="number" name = "num1"><br>
                    <br>
                    <i>Podaj dodatni całkowity wykładnik potęgi:</i> <input type = "number" class="number" name = "num2"><br>
                    <br>
                    <div class = "buttonContainer">
                        <input type="submit" value = "POTĘGOWANIE" name = "oblicz">
                    </div>
                </form>
            </section>

        </main>
        <div style = "text-align: center">
            <br>
            <?php
                if (isset($_GET["oblicz"])) {
                    $n1 = $_GET["num1"];
                    $n2 = $_GET["num2"];
                    if ($n1 == "" || $n2 == "") {
                        echo "Wpisz podstawę i wykładnik potęgi.";
                    } else {
                        if ($n2 > 0) {
                            echo "Wynik działania wynosi: ".(pow($n1, $n2));
                        } else {
                            echo "Wykładnik potęgi musi być dodatni. ";
                        }
                    }
                }
            ?>
            </div>
    </body>

</html>

<?php



?>