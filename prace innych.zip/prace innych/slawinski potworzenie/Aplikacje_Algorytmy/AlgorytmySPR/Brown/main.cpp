#include <iostream>
#include <time.h>
#include <stdlib.h>
#include <math.h>
#include <fstream>

using namespace std;

int randomInt(int a, int b) {
    return rand()%(b-a+1)+a;
}

float randomFloat(float a, float b) {
    return ((float)rand()/RAND_MAX)*(b-a)+a;
}

float getPI() {
    long ikw = 1000000;

    int iko = 0;
    int i = 1;
    float x = 0;
    float y = 0;
    int r = 1;
    iko += ikw*0.25;
    ikw = ikw*0.75;
    do {
        x = randomFloat(0, 1);
        if (x > 0.5) {
            y = randomFloat(0, 1);
        } else {
            y = randomFloat(0.5, 1);
        }


        if (x*x + y*y <= r*r) {
            iko++;
        }
        i++;
    } while (i<=ikw);

    return (float)(4*iko)/(float)ikw;
}

int main()
{
    float PI = getPI();
    float x = 0;
    float y = 0;
    float alpha;
    srand(time(NULL));

    fstream outputFile;

    outputFile.open("output.xls", ios::out);
    outputFile<<x<<"\t"<<y<<endl;
    for (int i = 0; i < 1000; i++) {
        alpha = randomFloat(0, 2*PI);
        x += cos(alpha);
        y += sin(alpha);
        outputFile<<x<<"\t"<<y<<endl;

    }
    outputFile.close();

    return 0;
}
