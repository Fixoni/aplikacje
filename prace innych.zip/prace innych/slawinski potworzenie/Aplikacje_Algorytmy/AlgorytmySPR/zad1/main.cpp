#include <iostream>
#include <time.h>
#include <stdlib.h>
#include <math.h>
#include <fstream>

using namespace std;

int randomInt(int a, int b) {
    return rand()%(b-a+1)+a;
}

float randomFloat(float a, float b) {
    return ((float)rand()/RAND_MAX)*(b-a)+a;
}

int main() {
    float x,y;
    x = 0;
    y = 0;
    srand(time(NULL));

    fstream outputFile;

    outputFile.open("output.xls", ios::out);
    int i = 0;
    while (i < 500) {
        x = randomFloat(0,2);
        y = randomFloat(0,2);
        if (x*x + y*y >= 4) {
            cout << x << " " << y << endl;
            outputFile<<x<<","<<y<<endl;
            i++;
        }


    }
    outputFile.close();

    return 0;
}
