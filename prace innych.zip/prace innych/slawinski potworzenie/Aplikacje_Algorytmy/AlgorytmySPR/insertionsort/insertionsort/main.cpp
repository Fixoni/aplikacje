#include <iostream>
#include <time.h>
#include <fstream>

using namespace std;

void insertionSort(int tab[], int n) {
    int temp;
    int k;
    for (int i = 1; i < n; i++) {
        temp = tab[i];
        k = i - 1;
        while (k >= 0 && tab[k] > temp) {
            tab[k+1] = tab[k];
            k = k - 1;
        }
        tab[k+1] = temp;
    }
}

int main()
{
    int n = 30;
    srand(time(NULL));
    fstream file;
    file.open("output.txt", ios::out);
    file <<"Przed posortowaniem:";

    int tab[n];
    cout << "Przed posortowaniem:";
    for (int i = 0; i < n; i++) {
        tab[i] = rand()%101;
        cout << " " << tab[i];
        file << " " << tab[i];
    }

    insertionSort(tab, n);

    cout << endl << "Po posortowaniu:";
    file << endl << "Po posortowaniu:";
    for (int i = 0; i < n; i++) {
        cout << " " << tab[i];
        file << " " << tab[i];

    }

    file.close();
    return 0;
}


/*

tablic� dwuwymiarow� 10x20, wype�nij tak, aby ka�dy wiersz zaczyna� si� od 10-ciu i r�nica pomi�dzy elementami w wierszu zwi�ksza si� o 1 w ka�dym wierszu, a w 1 wierszu wynosi 1

*/
