#include <iostream>
#include <time.h>
#include <fstream>

using namespace std;


int main()
{
    int tab[10][20];
    for (int i = 1; i <= 10; i++) {
        for (int j = 0; j < 20; j++) {
            tab[i-1][j] = 10 + j * i;

            cout << tab[i-1][j] << " ";
        }
        cout << endl;
    }
    return 0;
}


/*

tablic� dwuwymiarow� 10x20, wype�nij tak, aby ka�dy wiersz zaczyna� si� od 10-ciu i r�nica pomi�dzy elementami w wierszu zwi�ksza si� o 1 w ka�dym wierszu, a w 1 wierszu wynosi 1

*/
