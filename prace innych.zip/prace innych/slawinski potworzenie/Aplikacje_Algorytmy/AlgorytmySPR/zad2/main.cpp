#include <iostream>
#include <fstream>
//Z pliku pobierz 10 liczb naturalnych wi�kszych od 1, wypisz je i obok ka�dej z nich wypisz jej rozk�ad na czynniki pierwsze
using namespace std;

void rozklad(int num) {
    int d = 2;
    while (true) {
        if (num % d == 0) {
            num = num / d;
            cout << d << " ";
        } else {
            if (d < num) {
                d++;
            } else {
                return;
            }

        }
    }
}

int main()
{
    fstream dataFile;
    dataFile.open("Numbers.txt", ios::in);
    int num;
    for (int i = 0; i < 10; i++) {
        dataFile>>num;
        cout << num << " ---> ";
        rozklad(num);
        cout << endl;
    }
    return 0;
}
