#include <iostream>
#include <fstream>

using namespace std;

int abs(int a) {
    return (a < 0) ? a * -1 : a;
}

bool isPrimal(int a) {
    if (a == 1) return false;
    int d = 2;
    while (d<a) {
        if (a%d == 0) {
            return false;
        }
        d++;
    }
    return true;
}

int main()
{
    int Count = 0;
    fstream dane;
    dane.open("dane4.txt", ios::in);
    int a = 1;
    int b = 1;
    for (int i = 0; i < 2000; i++) {
        b = a;
        dane>>a;
        if (isPrimal(a) && isPrimal(b)) {
            if (abs(a - b) == 2) {
                Count++;
                cout<<b<<" i "<<a<<endl;

            }
        }

    }
    cout<<endl<<"Liczba par: " <<Count<<endl;
    dane.close();


    return 0;
}
