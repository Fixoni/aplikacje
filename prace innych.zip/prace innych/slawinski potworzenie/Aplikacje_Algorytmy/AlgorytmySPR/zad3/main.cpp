#include <iostream>
#include <math.h>;
#include <time.h>;

using namespace std;
//Wylosowa� 2 liczby ca�kowite z przedzia�u od 10 do 50 i dla wylosowanych liczb wyznaczy� nwd;

int NWD(int a, int b) {
    while (a != b) {
        if (a>b) {
            a-=b;
        }
        else {
            b-=a;
        }
    }
    return a;
}

int main()
{
    srand(time(NULL));
    int a,b;

    b = rand()%(50-10+1)+10;
    a = rand()%(50-10+1)+10;

    cout << "a: " << a << ", b: " << b;
    cout << " NWD: " << NWD(a,b) << endl;

    return 0;
}
