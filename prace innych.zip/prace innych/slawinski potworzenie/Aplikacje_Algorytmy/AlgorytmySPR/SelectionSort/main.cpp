#include <iostream>
#include <time.h>


using namespace std;

void selectionSort(int tab[], int n) {
    int smallest = 0;
    int temp;
    for (int i = 0; i < n - 1; i++) {
        smallest = i;
        for (int j = i + 1; j < n; j++) {
            if (tab[j] < tab[smallest]) {
                smallest = j;
            }
        }
        temp = tab[smallest];
        tab[smallest] = tab[i];
        tab[i] = temp;
    }
}

int main()
{
    srand(time(NULL));
    int  n = 10;
    int tab[n];
    int a;


    do {
        for (int i = 0; i < n; i++) {
            tab[i] = rand()%10;
            cout<<tab[i]<<" ";
        }
        cout<<endl;
        selectionSort(tab, n);
        for (int i = 0; i < n; i++) {
            cout<<tab[i]<<" ";
        }
        cout<<endl<<endl;
        cin>>a;
    } while(true);

    return 0;
}
