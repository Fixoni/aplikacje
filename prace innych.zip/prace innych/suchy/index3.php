<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>nauczyciel</title>
</head>
<body>
<form action="" method="post">
    <h1>DANE NAUCZYCIELA</h1>
    <label for="nazwisko">nazwisko</label>
    <input type="text" id="nazwisko" name="nazwisko" required><br><br>
  <label for="przedmioty">Wybierz przedmiot(y):</label><br><br>
  <select multiple name="przedmioty[]">
    <?php
    $file = fopen("dane3.txt","r");
    for($i=0; $i<=5; $i++){
        $a = fgets($file);
        echo "<option value='$a'>$a</option>";
    }
    ?>
  </select><br><br>
  <p>stopien nauczyciela:</p>
  <input type="radio" id="stopien1" name="stopien" value="stażysta">
  <label for="stopien1">stażysta</label><br>
  <input type="radio" id="stopien2" name="stopien" value="mianowany">
  <label for="stopien2">mianowany</label><br>  
  <input type="radio" id="stopien3" name="stopien" value="dyplomowany">
  <label for="stopien3">dyplomowany</label><br><br>

  <label for="staz">staz</label>
  <input type="number" name="staz"><br><br>

  <button type="submit">potwierdz</button>
</form>

<?php
if(isset($_POST['nazwisko'])){
    $nazwisko=$_POST['nazwisko'];
}
else{$nazwisko='';}
if(isset($_POST['staz'])){
    $staz=$_POST['staz'];
}
else{$staz='';}
if(isset($_POST['stopien'])){
    $stopien=$_POST['stopien'];
}
else{$stopien='';}
if(isset($_POST['przedmioty'])){
    $przedmioty=$_POST['przedmioty'];
}
else{$przedmioty=array();}

if($nazwisko=='' || $staz=='' || empty($przedmioty)){
    echo "<a>uzupelnij dane</a>";
}
else{
    echo "$nazwisko wykonuje staz $staz lat ma stopien $stopien i uczy przedmioty: ";
    foreach($przedmioty as $przedmiot){
        echo "$przedmiot, ";
    }
    if($stopien=="stażysta"){
        $zarobki = 3000 + ($staz * 100);
    }
    elseif($stopien=="mianowany"){
        $zarobki = 3500 + ($staz * 100);
    }
    else{
        $zarobki= 4000 + ($staz * 100);
    }
    echo "<br><br>Zarobki nauczyciela: $zarobki złotych";
}
?>

</body>
</html>