<?php
/*zad4.
zdeklaruj tablice z tablicy  i wypelnij tak samo.wypisz w takiej postaci jak jest na tablicy .
*/


$tab = Array();
$tab["Kowalski"]["polski"]=3;
$tab["Kowalski"]["historia"]=4;
$tab["Nowak"]["polski"]=2;
$tab["Nowak"]["historia"]=5;
echo"<table>";

$first = true;
foreach($tab as $klucz => $wartosc)
{
  if($first)
  {
    echo "<tr>";
    echo "<th>";
    echo "</th>";
    foreach($wartosc as $klucz2 => $wartosc2)
    {
        echo "<th>".$klucz2."</th>";

        
    }
    echo "</tr>";
    $first=false;
    echo "<th>".$klucz."</th>";
    foreach($wartosc as $wartosc2 => $klucz)
    {
        
     echo "<td>".$wartosc2."</td>";
     
    }
    
    
  }
}
echo "</table>";



?>