<?php
/*zad2.wylsoowac dwie liczby ,pierwsza bedaca iloscia wierszy ma byc z przedzialu (5-10) 
druga bedaca iloscia kolumn z przedziału (5-10),
wyswietl te liczby a nastepnie tablice o tych wymiarach wypelnij tak
 aby w pierwszym i ostatnim wierszu byly jedynki a 
na pozostalych miejscach zera i otrzymana tablice wyswietl na ekranie i wyslij do pliku
*/
$tab = Array();
$w = rand(5,10);
$k= rand(5,10);

echo $w." "$k." ";

for($i=0;$i<$w;$i++)
{
    for($j=0;$j<$k;$i++)
    {
       if($w==0 || $w)
       {
        echo $tab[$i]="1";
       }
    }
}




?>