<?php
/*zad1.z pliku pobierz liczbe bedaca rozmiarem tablicy ,
pobrac liczbe i wyswietlic a nastepnie tablice o tym rozmiarze wypelnic tak aby
 na indeksach podzielnych przez 3 (0,3,6...)
 byla liczba 9 a na pozostaluych miejscach liczba 5,wyswietl tablice 
 */
$tab = Array();

$plik = fopen("plik.txt","r");
$a = fgets($plik);

echo $a." ";

echo "<br>";

for($i=0;$i<=$a;$i++)
{
    
    if($i%3==0)
    {
        
        echo  $tab[$i]="9"." ";
    }
    else{
        echo  $tab[$i]="5"." ";
    }
    
}







?>