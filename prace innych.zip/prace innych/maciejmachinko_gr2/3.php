<?php
/*zad3.
zadeklaruj i wypelnij tablice asocjacyjne
 gdzie kluczami sa nazwy przedmiotow a wartosciami liczby bedace cena w zł.
wypelnij ja 6 rekordami wyswiel je w postaci nazwa przedmiotu - cena=zl.oblicz sume cen wprowadzonych przedmiotow.
*/

$tab = Array();
$tab["szczotka"]=20;
$tab["suszarka"]=50;
$tab["piórnik"]=15;
$tab["naszyjnik"]=100;
$tab["klucz"]=10;
$tab["pilot"]=5;

$s=0;

foreach($tab as $klucz => $wartosc)
{
    echo $klucz." cena: ".$wartosc." ";
    $s=$s+$wartosc;
    echo "<br>";
}
echo "<br>";
echo "suma cen przedmiotow = ".$s;









?>