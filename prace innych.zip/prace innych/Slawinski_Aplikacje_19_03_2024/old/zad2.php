<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
    <form method = "post">
        Number_min: <input type="number" step = "1" name = "number_min" required><br>
        Number max: <input type="number" step = "1" name = "number_max" required><br>
        <button type = "submit" name = "submit">Losuj</button>
    </form>
</body>
</html>

<?php

/*

    z pliku pobierz liczbę będącą rozmiarem tablicy, a z formularza 2 liczby będące zakresem losowania liczb do tablicy
    wyświetl elementy tablicy, posortuj ją malejąco, dodaj na końcu liczby 100, 200, 300

    z tablicy utwórz łańcuch, potasuj znaki w tym łańcuchu i wyznacz sumę kodów asci wszystkich elementów
    znajdujących się w łańcuchu

*/

if (isset($_POST["submit"])) {
    $file = fopen("dane.txt", 'r');
    $num = fgets($file);
    fclose($file);
    $tab = Array();

    for ($i = 0; $i < $num; $i++) {
        $tab[$i] = rand($_POST["number_min"], $_POST["number_max"]);
        echo $tab[$i] . " ";
    }
    echo "Posortowana tablica: <br>";
    rsort($tab);
    for ($i = 0; $i < $num; $i++) {
        echo $tab[$i] . " ";
    }
    echo "Dodano 100, 200, 300: <br>";
    array_push($tab, 100, 200, 300);
    for ($i = 0; $i < sizeof($tab); $i++) {
        echo $tab[$i] . " ";
    }
    shuffle($str);
    $str = implode($tab);
    echo "String: <br>";
    
    echo $str."<br>";
    $s = 0;
    for ($i = 0; $i < strlen($str); $i++) {
        $s += ord($str[$i]);
    }

    echo "Suma kodów asci: " . $s;
}

?>