<?php
    $date = getdate();
    $weekdays = Array("Niedziela", "Poniedziałek", "Wtorek", "Środa", "Czwartek", "Piątek", "Sobota");
    $months = Array("Grudzień", "Styczeń", "Luty", "Marzec", "Kwiecień", "Maj", "Czerwiec", "Lipiec", "Sierpień", "Wrzesień", "Listopad");
    echo "Dzisiaj jest " . $weekdays[$date["wday"]] . ", " . ($date["mday"] < 10 ? "0".$date["mday"] : $date["mday"]) . " " . $months[$date["mon"]] . " " . $date["year"] . "<br>";

    echo ($date["hours"] < 10 ? "0".$date["hours"] : $date["hours"]).":".($date["minutes"] < 10 ? "0".$date["minutes"] : $date["minutes"]) . "<br>";

    echo "Timestamp: " . $date["0"] . "<br>";
    echo "Dzień roku: " . $date["yday"] . "<br>";

    echo date("Y-m-d") . "<br>";
    echo date("d-m-Y") . "<br>";
    echo date("G:i:s") . "<br>";
    echo date("H-i-sa") . "<br>";
    echo date("d-m-Y G:i:s") . "<br>";
    echo date("Y-m-d G:i:s") . "<br>";

    $d = getdate();
    $dd = getdate(mktime(0, 0, 0, 6, 21, 2024));

    echo "Pozostało dni: " . $dd["yday"] -  $d["yday"] . "<br>";

?>