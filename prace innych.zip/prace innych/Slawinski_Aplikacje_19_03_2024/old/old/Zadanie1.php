<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Funkcje Tablicy</title>
</head>
<body>
<?php
$plik = fopen("dane.txt","r");
$o = fgets($plik);
$tab = array();
// echo "Rozmiar tablicy to: ". $o;
echo "Nieposortowana tablica: ";
echo "<br>";
for($i=0;$i<$o;$i++){
    $tab[$i] = rand(1,100);
    echo $tab[$i]." ";
}


echo "<br>";
echo "Posortowana tablica: ";
sort($tab);
echo "<br>";
for($i=0;$i<$o;$i++){
    echo $tab[$i]." ";
}
echo "<br>";
echo "Ile razy w tablicy znajduję się liczba 15: ";
echo "<br>";
$a = array_count_values($tab)[15];
echo $a;
echo "<br>";

echo "Usunięcie ostatniego elementu tablicy i wyświetlenie jej rozmiaru: ";
echo "<br>";
array_pop($tab);
$b = count($tab);
echo $b;
echo "<br>";

echo "Dodawanie wartości do elementów tablicy: ";
echo "<br>";
$c=array_push($tab,777,888,999);
for($i=0;$i<count($tab);$i++){
    echo $tab[$i]." ";
}
echo "<br>";
echo "Funkcja Unshift i jej zastosowanie: ";
echo "<br>";
array_unshift($tab,1000,1001);
echo "<br>";
for($i=0;$i<count($tab);$i++){
    echo $tab[$i]." ";
}
echo "<br>";
echo "Sortowanie tablicy malejąco: ";
echo "<br>";
rsort($tab);
for($i=0;$i<count($tab);$i++){
    echo $tab[$i]." ";
}
echo "<br>";

echo "Funkcja array_unique(pomijanie duplikatów indeksów): ";
echo "<br>";
print_r(array_unique($tab));
echo "<br>";

echo "Funkcja replace: ";
echo "<br>";
//deklaracja drugiej tablicy
$tab2 = array(-15,-16,-17);
print_r(array_replace($tab,$tab2));
for($i=0;$i<count($tab);$i++){
    echo $tab[$i]." ";
}
echo "<br><br>";
echo "Splice: ";
echo "<br><br>";
array_splice($tab,5,3,$tab2);
for($i=0;$i<count($tab);$i++){
    echo $tab[$i]." ";
}
echo "<br><br>";

echo "Suma elementów tablicy: ";
echo "<br><br>";
$d = array_sum($tab);
echo $d;
echo "<br><br>";



$tab3 = array("Kowalski"=>3.5,
"Bielecki" => 3.3,
"Krakowiak" => 0.1,
"Mastka" => 4.5,
"Pleśniak" =>2.5
);
foreach($tab3 as $nazwisko => $ocena){
    echo "Uczeń ". $nazwisko ." ma średnią ocen: ". $ocena;
    echo "<br>";
}
echo "<br><br>";
echo "Sortowanie tablicy według kluczy: ";
echo "<br><br>";
ksort($tab3);
foreach($tab3 as $nazwisko => $ocena){
    echo "Uczeń ". $nazwisko ." ma średnią ocen: ". $ocena;
    echo "<br>";
}
echo "<br><br>";

echo "Sortowanie tablicy malejąco według wartości: ";
echo "<br><br>";
arsort($tab3);
foreach($tab3 as $nazwisko => $ocena){
    echo "Uczeń ". $nazwisko ." ma średnią ocen: ". $ocena;
    echo "<br>";
}
echo "<br><br>";

print_r(array_keys($tab3));
echo "<br><br>";
echo array_search(3,$tab3);
echo "<br><br>";
print_r(array_slice($tab3,1,2));


?>
</body>
</html>