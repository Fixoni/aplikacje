<?php
    class Osoba {
        public $nazwisko;
        public $wzrost;
        public function wypisz() {
            echo "Nazwisko: ".$this->nazwisko.", Wzrost: ".$this->wzrost."cm<br>";
        }

        public function czyWysoki() {
            return ($this->wzrost > 180 ? "tak" : "nie");
        }
    }

    $osoba = new Osoba();
    $osoba->nazwisko = "Sławiński";
    $osoba->wzrost = 182.5;
    $osoba->wypisz();

    echo "Czy wysoki: " . $osoba->czyWysoki() . "<br>";
?>