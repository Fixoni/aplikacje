#include <iostream>

using namespace std;

class Pojazd {
    public :
    string marka,kolor;
    int rocznik;
    Pojazd() {
        marka = "Fiat 126p";
        kolor = "czerwony";
        rocznik = 2020;
    }
    Pojazd(string marka, string kolor, int rocznik) {
        this->marka = marka;
        this->kolor = kolor;
        this->rocznik = rocznik;

    }

    void malowanie() {
        kolor = "czarny";
        cout << "przemalowano" << endl;
    }

    void pokazInfo() {
        cout << "Marka: " << this->marka << ", Kolor: " << this->kolor << ", Rocznik: " << this->rocznik << endl;
    }

    ~Pojazd() {
        cout << "Zlomowanie pojazdu" << endl;
    }
};

int main()
{
    Pojazd autko = Pojazd("Nissan Skyline R34 GT-R", "niebieski", 2002);
    autko.pokazInfo();
    autko.malowanie();
    autko.pokazInfo();
    return 0;
}
