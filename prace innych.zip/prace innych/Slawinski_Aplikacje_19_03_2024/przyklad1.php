<?php
    /*

    */
    class Pojazd {
        public $marka;
        public $kolor;
        public $rocznik;

        function __construct($marka = "Fiat 126p", $kolor = "czerwony", $rocznik = 1982) {
            $this->marka = $marka;
            $this->kolor = $kolor;
            $this->rocznik = $rocznik;
        }

        function __destruct() {
            echo "<br>Usunięto obiekt";
        }

        public function malowanie() {
            $this->kolor = "czerwony";
            echo "<br>przemalowano auto";
        }

        public function falszowanieRocznika($nowyRocznik) {
            echo "<br>Zmieniono rocznik z ".$this->rocznik." na ".$nowyRocznik;
            $this->rocznik = $nowyRocznik;
            
        }

        public function pokazInfo() {
            echo "<br>Kolor auta: ".$this->kolor.", marka: ".$this->marka.", rocznik: ".$this->rocznik;
        }
    }

    // $auto = new Pojazd("Nissan Skyline R34 GT-R", "Niebieski", 2001);
     $auto = new Pojazd();
    // $auto->marka = "Opel";
    // $auto->kolor = "czarny";
    // $auto->rocznik = 2020;

    $auto->pokazInfo();

    $auto->malowanie();

    $auto->pokazInfo();

    $auto->falszowanieRocznika(2024);

    $auto->pokazInfo();
?>