<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
    <form method = "post">
        Licznik: <input type="number" step = "1" required name = "licznik"><br>
        Mianownik: <input type="number" step = "1" required name = "mianownik"><br>
        <button name = "submit" type = "submit">Zatwierdź</button>
    </form>
</body>
</html>

<?php
    /*

    */
    class Ulamek {
        public $licznik;
        public $mianownik;
        function __construct($licznik = 0, $mianownik = 1) {
            $this->licznik = $licznik;
            $this->mianownik = $mianownik;
        }

        public function wypisz() {
            echo $this->licznik."/".$this->mianownik."<br>";
        }

        public function skrocPrzezNWD() {
            if ($this->licznik < 0 ) {
                $this->licznik = $this->licznik * -1;
            }
            if ($this->mianownik < 0 ) {
                $this->mianownik = $this->mianownik * -1;
            } else if ($this->mianownik == 0) {
                echo "BŁĄD: Mianownik nie może wynosić 0!<br>";
            }
            $a = $this->licznik;
            $b = $this->mianownik;
            while ($a != $b) {
                if ($b > $a) {
                    $b -= $a;
                } else {
                    $a -= $b;
                }
            }
            $this->licznik /= $a;
            $this->mianownik /= $a;
        }

        public function skroc() {
            $l = $this->licznik;
            $m = $this->mianownik;
            $i = 2;
            while ($i <= $l) {
                if ($m % $i == 0 && $l % $i == 0) {
                    $l /= $i;
                    $m /= $i;
                } else {
                    $i++;
                }
            }
            $this->licznik = $l;
            $this->mianownik = $m;
        }
    }

    if (isset($_POST["submit"])) {
        $ulamek = new Ulamek($_POST["licznik"], $_POST["mianownik"]);
        $ulamek->wypisz();
    
        $ulamek->skrocPrzezNWD();
        echo "Po skróceniu: <br>";
        $ulamek->wypisz();
    }

?>