<!-- z pliku pobierz dwie liczby naturalne pierwsza oznacza ilosć druga oznacza ilosć kolumn tablicy dwuwymarowej
tablica ta wypełnij tak aby na pierwszym miejscu była liczba dwa a każda następna wartosć idąć po wierszch była większa o 3
od poprzedniej wyswietl na stronie i zapis do pliku  -->
<!-- utwórz tablice asocjacyjną gdzie kluczbami są nazwy twoarów natmiast wartościami ich cena wypełnij ich tablice
20 rekoradmi gdzie nazwy towarów będą pobrane z plia ceny będą liczbami losowymi z przediału 10 do 99 wypisz
tablice w  postaci nawa | cena | -->
<!-- w pliku napisz 6 rekordów (linijek) skłądających się z nazwiska i liczby bedącej wiekiem pobierz danie pliku
wyświetl je w postaci nazwisko | wiek  znajdż najstarszą osobę nazwisko i wiek -->


<?php

// $tab = array();
// $plik = fopen("tablica.txt","r");
// $kolumny = fgets($plik);
// $wiersze = fgets($plik);
// $dodaj = 2; 
// fclose($plik);
// $plik = fopen("zapis.txt","w");
// for($i = 0; $i<$kolumny; $i++)
// {
//     for($j = 0; $j<$wiersze; $j++)
//     {
//         echo " ".$tab[$i][$j] = $dodaj." ";
//         fwrite($plik,$tab[$i][$j]);
//         $dodaj = $dodaj+3;
//     }
//     fwrite($plik,"\n");
//     echo "<br>";
// }

// $tab = array();
// $plik = fopen("towary.txt","r");

// while($towar = fgets($plik))
// {
//     $tab[$towar] = rand(10,99)." zł";
// }
// foreach ($tab as $klucz => $wartość) {
//     echo $klucz;
//     echo "cena : ".$wartość."<br>";

// }
// $tab = array();
// $tab2 = array();
// $plik = fopen("nazwiska.txt","r");
// $linjka;
// while($linijka = fgets($plik))
// {
//      $linijka;
//     $tab = explode(" ",$linijka);
//     $tab2[$tab[0]] = $tab[1];
// }
// $naj = 0;
// $naj2;
// foreach ($tab2 as $klucz => $wartosc) {
//     echo "nazwisko : ".$klucz." wiek : ".$wartosc."<br>";
//     if($wartosc > $naj)
//     {
//         $naj = $wartosc;
//         $naj2 = $klucz;
//     }
// }
// echo "najstarsza osoba : nazwisko : ".$naj." wiek : ".$naj2."<br>"
$miasta = array();
$miasta["ludnosc"]["wroclaw"] = 680;
$miasta["powierchnia"]["wroclaw"] = 297;
$miasta["ludnosc"]["krakow"] = 900;
$miasta["powierchnia"]["krakow"] = 327;
echo "<table border ='1'>";
echo "<tr>
    <th> </th>";
$a = true;
foreach ($miasta as $key => $value) {
    if($a){
    foreach ($value as $key2 => $value2) {
        echo "<th>".$key2."</th>";
    }}
    $a = false;
}
echo "</tr>";
foreach ($miasta as $key => $value) {
    echo "<tr>
    <th>".$key." </th>";
    foreach ($value as $key2 => $value2) {
    echo "<td>".$value2."</td>";
    
    }
    echo "</tr>";
 }
echo "</table>";
?>
