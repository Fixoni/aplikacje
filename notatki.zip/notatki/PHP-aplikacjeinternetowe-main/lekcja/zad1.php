<?php
function wypisztab($w,$k,$tab){
   for ($i=0; $i <$w ; $i++) {  
        for ($j=0; $j <$k ; $j++) { 
            echo    $tab[$i][$j]." ";
        }  
        echo "<br>";
}
return 0;
}
/*
    for ($i=0; $i <$w ; $i++) {  
        for ($j=0; $j <$k ; $j++) { 
            if($i%2 == 0){
          if($j%2 == 0)
             {
                $tab[$i][$j] = "X";
            } 
            else{
                $tab[$i][$j] = 0;
            }
        }
        else if($j%2 != 0)
        {
            $tab[$i][$j] = "X";
        }
        
            else{
            $tab[$i][$j] = 0;
        }
        
        }  
        }
*/









$tab = array(); 

// sort rosnaca rsort malejaco print_r
//wypisztab($w,$k,$tab);
/*for ($i=0; $i < 20 ; $i++) { 
    $tab[$i] = rand(100,1000);
    echo " ".$tab[$i];
}
echo "<br>";

for ($i=0; $i < 20 ; $i++) { 
    sort($tab);
    echo " ".$tab[$i];
}
echo "<br>";
for ($i=0; $i < 20 ; $i++) { 
    rsort($tab);
    echo " ".$tab[$i];
}
echo "<br>"; 
    print_r($tab);
    echo "<br>";*/
    for ($i=0; $i <30 ; $i++) {  
            if($i%3 == 0){
            $tab[$i] = 7;}
            else{
            $tab[$i] = 0;}
            echo $tab[$i]." ";
}

/*wypisztab($w,$k,$tab);
print_r($tab);
for($w2 =0; $w2 < $w; $w2++){
for ($i=0; $i <$k ; $i++) {  
        $tab2[$w2][$i] = $tab[$i][0];
}
}*/

?>