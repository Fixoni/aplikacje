<?php

WSTAWIANIE OBRAZKA 
echo"To moj pierwszy skrypt.";
echo"<br>";
echo"wstawiam obrazem o nazwie <i>obrazek1.jpg</i>";
echo"<img src=\"obarazek.jpg\" alt='kotik'>";

WYPISYWANIE LICZB POMIĘDZY
$a=300;
$b=200;
echo"podano liczby $a , $b";
echo"<br>";
if($a<$b)
{
    $a++;
    while($a<$b){
        print"<br>";
        print $a;
        $a++;
        print"<br>";
        
    }
}else if($b<$a)
{
    $a--;
    while($b<$a){
        print"<br>";
        print $a;
        $a--;
        print"<br>";
    }

}



$a=2;
$c=3;
$s=2;
for($b=1;$b<=30;$b++)
{
print "$b dzień $a zł ----> $s zł<br>";  
$a=$a+$c;
$s=$s+$a;


}


                                wypisywanie liczb parzystych i nieparzystych
$sp=0;
$sn=0;
for($a=10;$a<100;$a++)
{
    if($a%2==0)
    {
        print "<b> $a </b> <br>";
        $sp=$sp+$a;



    }else
    {
        print "$a <br>";
        $sn=$sn+$a;
    }
}
echo "suma przystych liczb <b>$sp</b> a suma nieparzystych liczb $sn";



                            Wypisywanie odwrotności liczby
$a=57;
print "$a<br>";

$j=$a%10;
$d=($a-$j)/10;
$c=$j*10+$d;
print "$c<br>";
*/

?>
<?php

                        WYNIK DODAWANIA 
funkcja dodająca

$x=12;
$y=21;

function suma($x,$y)
{
    $s=$x+$y;
    return $s;

}
echo suma($x,$y);


                        SUMA CYFR
$a=256;


function sumacyfr($a)
{
    $s=0;
    while($a!=0)
    {
        $r=$a%10;
        $s=$s+$r;
        $a=($a-$r)/10;

    }
    return $s;


}
echo "suma cyfr $a wynosi ".sumacyfr($a);




                                     POTĘGA
function power($a, $n)
{
        
        $p=$a;
        for($i=1; $i<$n;$i++)
        {
            $p=$p*$a;
        }
        return $p;
}


                    ZAMIANA CYFR PIERWSZEJ I OSTATNIEJ

function zamiana($a)
{
    $beg = $a;
    $r2= 0 ;
    $r = $a%10;
    $c=0;
while($a !=0){
        $r2=$a%10;
        $a=($a-$r2)/10;
        $c+=1;
}
    $n=($r * power(10, $c-1))+ $r2 +($beg - $r2*power(10, $c-1) - $r);
    return $n;

}

$liczba= 123412;
echo"Liczba ".$liczba."<br>";
echo"<br>Wynik: ".zamiana($liczba);


                                    SILNIA
echo silnia(5);
function silnia($a)
{
    $s=1;
    for($i=1; $i<=$a; $i++)
    {
        $s=$s*$i;
    }

    return $s;
}


                Wypisz najmniejszą
echo najliczba(421,199,53);
function najliczba($a,$b,$c)
{
if($a<$b&&$a<$c)
{
    echo "najmniejsza liczba to $a ";
}

elseif($b<$c&&$b<$c)
{
    echo "najmniejsza liczba to $b ";
}
elseif($c<$a&&$c<$b)
{
    echo "najmniejsza liczba to $c ";
}

}


zwiększanie
echo sumae(2,5);
function sumae($a,$b)
{
    $s=0;
    for($i=$a; $i<=$b;$i++)
    {
        $s=$s+$i;
    }
    return $s;
}



?>