<?php
/*
$w=10;
$k=7;
$s=0;
$tab=Array();

for($i=0;$i<$w;$i++)
{
    for($j=0;$j<$k;$j++)
    {
        $tab[$i][$j]=rand(10,99);
        echo $tab[$i][$j]." ";
        $s=$s+$tab[$i][$j];
    }
    echo "<br>";
   
}
echo "suma liczb w tabeli to: ".$s;
rand(10,99)
*/


/*
$w=11;
$k=11;

$tab=Array();

for($i=0;$i<$w;$i++)
{
    for($j=0;$j<$k;$j++)
    {
       if($i==$j || $i+$j==$w-1)
       {
         $tab[$i][$j]=1;
       }
       else
       {
          $tab[$i][$j]=0;
       }
       echo $tab[$i][$j]." ";
    }
    echo "<br>";
   
}


/*
$w=5;
$k=10;
$tab=Array();
for($i=0;$i<$w;$i++)
{
for($j=0;$j<$k;$j++)
{
    if(($i+$j)%2==0)
    {
        $tab[$i][$j]='X';
    }
    else
    {
         $tab[$i][$j]='0';
    }
    echo $tab[$i][$j]." ";
}
echo "<br>";
}
*/

/*
$tab=Array();
$r=20;
for($i=0;$i<=$r;$i++)
{
$tab[$i] = rand(100,999);
echo $tab[$i]." ";
}
sort($tab);
echo "<br>";
for($i=0;$i<=$r;$i++){
    echo $tab[$i]." ";
}
echo "<br>";
*/
/*
$tab=Array();
$tabTemp = Array();
$w=8;
$k=12;

for($i=0;$i<$w;$i++)
{
    for($j=0;$j<$k;$j++)
    {
    $tab[$i][$j]= rand(10,99);
    echo  $tab[$i][$j]." ";
   
    }
    echo "<br>";
    sort($tab[$i]);


}
echo "<br>";
for($i = 0;$i < $w;$i++)
{
    for($j=0;$j<$k;$j++)
    {
        $tabTemp[$i][$j] = $tab[$i][$j];
    }
}
for($j=0;$j<$w;$j++)
{
    sort($tabTemp[$j]);
}

for($i = 0;$i < $w;$i++)
{
    for($j=0;$j<$k;$j++)
    {
        $tab[$i][$j] = $tabTemp[$j][$i];
    }
}
echo "<br>";




for($i = 0;$i < $w;$i++)
{
    for($j=0;$j<$k;$j++)
    {
    
    echo  $tab[$i][$j]." ";
    
    }
    echo "<br>";
    sort($tab[$i]);


}
*/

//zad 1    tablice dwuwymiarowa o ilosci wierszy 10, kolumn 15 wypelnij tak  aby
 //środkowa kolumna(lub dwie środkowe) były liczbami losowymi jednocyfrowymi
 // a na pozostałych mniejscach stawimay liczby losowe dwucyfrowe.Wyznacz najwiekszy element tablicy.

/*
$tab=Array();
$w=10;
$k=16;

for($i=0;$i<$w;$i++)
{
    for($j=0;$j<$k;$j++)
    {
        if($k%2!=0)
        {
          if($j==($k-1)/2)
          {
            $tab[$i][$j]= rand(0,9);
            echo "<b>".$tab[$i][$j]. " </b>";
          }
          else
          {
            $tab[$i][$j]= rand(10,99);
            echo $tab[$i][$j]." ";
          }
          
        }
        else
        {
            if($j==$k/2-1 || $j==$k/2)
            {
                $tab[$i][$j] = rand(0,9);
                 echo "<b>".$tab[$i][$j]. " </b>";

            }
            else
            {
                $tab[$i][$j] = rand(10,99);
                echo $tab[$i][$j]." ";
            }
        }
        
    }
    echo "</br>";
}
$max=$tab[0][0];
for($i=0;$i<$w;$i++)
{
    for($j=0;$j<$k;$j++)
    {
        if($tab[$i][$j]>$max)
        {
            $max=$tab[$i][$j];
        }
    }
}
echo "Największym elementem jest: ".$max;
*/





//TABLICE ASOCJACYJNE
/*$tab=Array();

$tab["Kowalski"]=10;
$tab["Nowakowski"]=12;
$tab["Storecki"]=25;
$tab["Dobek"]=14;
$tab["Dabek"]=18;
$tab["Orzechowski"]=22;
$tab["Maslo"]=20;

$s=0;
$h=0;
foreach($tab as $n => $w)
{
    echo $n." wiek: ".$w. "lat/lata";
    echo "<br>";
    $s=$s+$w;
    $h++;
}
$s=$s/$h;
echo "srednia wieku wynosi: ".$s;
echo "<br>";
echo "elementy tablicy: ".count($tab);
*/
/*
$tab=Array("Róza"=>Czerwony,"Tulipan"=>zolty,"Fiolek"=>fioletowy,"lilia"=>bialy,"Krokus"=>niebieski,"slonecznik"=>zolty);



foreach($tab as $klucz => $wartosc)
{
    echo $klucz." Kolor: ".$wartosc."<br>";
}
echo "koloru czerwonego sa: ";
foreach($tab as $klucz => $wartosc)
{
    if($wartosc=="czerwony")
    {
        echo " ".$klucz;
    }
}
echo "<br>";
asort($tab);
foreach($tab as $klucz => $wartosc)
{
    echo $klucz." Kolor: ".$wartosc."<br>";
}
*/
/*
$sklep = Array();

$sklep[0]["nazwa"]="groszek";
$sklep[0]["ulica"]="groszkowa";
$sklep[0]["rodzaj"]="spozywczy";
$sklep[1]["nazwa"]="biedronka";
$sklep[1]["ulica"]="Stoczniowa";
$sklep[1]["rodzaj"]="spozywczy";



echo "<table border='1' >";
echo "<tr>";

foreach($sklep[0] as $klucz => $wartosc)
{
   
   

    echo "<th>".$klucz."</th>";
    
  


}
echo  "</tr>";
for($i=0;$i<count($sklep);$i++)
{
    echo "<tr>";
    foreach($sklep[$i] as $k => $w)
    {
        echo "<td>".$w."</td>";
    }
    echo "</tr>";
}
echo "</table>";
*/



//z pliku pobierz dwie liczby całkowite które stanowią zakres losowania elementów tablicy o rozmiarze 30 .Wyswietl pobrane liczby ,
//wyswietl elementy tablicy i elementy te wraz z ich średnią arytmetyczna,wyslij do pliku .  
/*
$tab=Array();
$plik=fopen('dane.txt','r');
$a = fgets($plik);
$b = fgets($plik);
fclose($plik);

echo "liczby: ".$a." ".$b;
echo "<br>";

$tab=Array();
$art=0;
for($i=0;$i<30;$i++)
{
    $tab[$i] = rand($a,$b);
    $art =$art+$tab[$i];

    echo " ".$tab[$i];
}
$art = $art/sizeof($tab);
echo " <br> Srednia liczb: ".$art;
$plik = fopen("tablica.txt","w");
for($i=0;$i<sizeof($tab);$i++)
{
    fwrite($plik, $tab[$i]." ");
}
fwrite($plik, "\n");
fwrite($plik, "srednia arytmetyczna: ".$art);
fclose($plik);
*/


//explode("separator","nazwa stringa")
//w pliku umieść 10 rekordów skladającychs się z nazwiska i liczby oznaczającej wiek,pobierz dane z pliku wyswietl je na satronie w postaci nazwisko,wiek:
//Wyznacz srednia wieku
/*
$tab=Array();
$dane = fopen("dane.txt","r");
$srednia=0;


for($i=1;$i<10;$i++)
{
  $wiersz = fgets($dane);
  $tab = explode(' ',"$wiersz");
  echo $tab[0]." wiek: ".$tab[1];
  $srednia= $srednia + $tab[1];
  echo "<br>";
 
}
$srednia= $srednia/10;
echo "średnia wieku = ".$srednia;
$zapis = fopen("srednia.txt","w");
fwrite($zapis, "srednia arytmetyczna = ".$srednia);
fclose($zapis);
fclose($dane);
*/
/*
$kraje=Array();
$kraje['Europa'][0]='Polska';
$kraje['Europa'][1]='Włochy';
$kraje['Europa'][2]='Hiszpania';
$kraje['Afryka'][0]='Nigeria';
$kraje['Afryka'][1]='Tunezja';
$kraje['Afryka'][2]='Egipt';
$kraje['Azja'][0]='Chiny';
$kraje['Azja'][1]='Indie';
$kraje['Azja'][2]='Japonia';

echo "<table border='1' >";
echo "<tr>";

foreach($kraje as $klucz => $wartosc)
{
    echo "<td>"."<b>".$klucz.": "."</b>"."</td>";
    for($i=0;$i<=2;$i++)
    {
        echo "<th>".$wartosc[$i]." "."</th>";
    }
    echo "<br>";
    echo "<tr>";
}
echo "</table>";
*/
$oceny=Array(
    'Historia'=>Array('Nowak'=>5,'Kowalski'=>3),
    'Matematyka'=>Array('Nowak'=>1,'Kowalski'=>4));

    echo "<table border='1' >";
    $first=true;
    

    foreach($oceny as $klucz => $wartosc)
    {
        if($first)
        {
            $first=false;
            echo "<th></th>";
            foreach($wartosc as $nazwisko2 => $oce2)
            {
                echo "<th>".$nazwisko2."</th>";
            }
        }
        echo "<tr>";
        echo "<td>".$klucz." "."</td>";
        
        
        foreach($wartosc as $nazwisko => $oce)
        {
            
            
            echo "<th>".$oce." "."</th>";
            
        }
        echo "<br>";
        echo "<tr>";

    }
    echo "</table>";
    $zapis = fopen("dane.txt","w");
    fwrite($zapis,"".$oceny);
    fclose($zapis);


































?>