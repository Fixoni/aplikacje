<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style3.css">
    <title>Twoje BMI</title>
</head>
<body>
    <div class="gora">
        <div class="logo">
            <img src="wzor.png" alt="wzór BMI">
        </div>
        <div class="baner">
            <h1>Oblicz swoje BMI</h1>
        </div>
    </div>
    <div class="main">
        <table>
            <tr>
                Interprenatcaj BMI
            </tr>
            <tr>
                Wartość minimalna
            </tr>
            <tr>
                Wartość maksymalna
            </tr>
            <?php/*
            for($i=0;$i<2;$i++) {
                $polaczenie=mysqli_connect("localhost","root","","egzamin");
                $zapytanie1="SELECT wart_min,wart_max FROM `bmi`;";
                $wynik=mysqli_query($polaczenie,$zapytanie1);
                echo "<td>".$wynik."<td>";
            }
            mysqli_close($polaczenie);*/
            ?>
        </table>
    </div>
    <div class="srodek">
    <div class="left">
            <h2>Podaj wage i wzrost</h2>
            <form action="" method="post">
                <label>Waga</label> <br>
                <input type="number" min="1" name="waga"> <br>
                <label>Wzrost</label> <br>
                <input type="number" min="1" name="wzrost"> <br>
                <button type="submit">Oblicz i zapamiętaj wynik</button>
            </form>
            <?php
            if(empty($_POST["waga"]) || empty($_POST["wzrost"])) {
                echo "Prosze wpisac dane";
            } else {
                $waga=$_POST["waga"];
                $wzrost=$_POST["wzrost"];
                $bmi=$waga/pow($wzrost,2)*10000;
                echo "Twoja waga: ".$waga." Twój wzrost: ".$wzrost."<br>";
                echo "BMI wynosi: ".$bmi;
            }
            ?>
    </div>

    <div class="right">
        <img src="rys1.png" alt="ćwiczenia">
    </div>
    </div>
    <footer>
        Autor: 0000000000
        <a href="kwerendy.txt">Zobacz kwerendy</a>
    </footer>
</body>
</html>