<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="" method="POST">
        <h2>Wybór ogrodzenia</h2>
        <select name="material" id="material">
        <option value="drewno">Drewno</option>
        <option value="beton">Beton</option>
        <option value="metal">Metal</option>
        </select>

        <br>
        Firma <input type="checkbox" name="firma">
        <br>
        <button type="submit">Oblicz</button>
    </form>
    <?php
    //wybierz ogredzenie metal drewno betonowe checkbox firma 
    //przycisk oblicz
    //drewno 5000 metal 7000 beton 6000
    //firma +2000
    $m=$_POST["material"];
    $f=$_POST["firma"];

   /*if($m=="Drewno") {

    }
    */

    $s=0;
    switch($m) {
        case "drewno":
            $s=$s+5000;
            break;
        case "beton":
            $s=$s+6000;
        break;
        case "metal":
            $s=$s+7000;
            break;
        default:
        echo "Wybierz dane";
        break;
    }
    if($f==true) { 
        $s=$s+2000;
    echo "Material: ".$m." Firma: tak ".$s;
    } else {
        echo "Material: ".$m." Firma: nie ".$s;
    }

    ?>
</body>
</html>