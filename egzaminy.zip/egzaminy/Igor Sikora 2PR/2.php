<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="" method="POST">
        <h2>Wybierz nazwisko</h2>
        <br>
        <select name="nazwisko" id="nazwisko">
            <?php
             $plik=fopen("dane.txt","r");
             for($i=0;$i<5;$i++) {
                $a=explode(" ",fgets($plik));
                echo "<option value=".$a[0]." ".$a[1].">".$a[0]."</option>";
             }
             fclose($plik);
            ?>
        </select>
        <br>
        Waga
        <input type="number" name="waga">
    </form>
    <?php
    //pobrac z pliku nazwisko jako lista jednokrotnego wyboru 
    //wzrost obok imienia
    //podaj wage
    //wyslij
    //wypisanie danych wiecej niz >=180cm wysoki w innym wypadku nie wysoki
    $n=$_POST["nazwisko"];
    $w=$_POST["waga"];
    $plik=fopen("dane.txt","r");
        $p=explode(" ",fgets($plik));
        if($n==true) {
            if($p[1]>=180) {
            echo "Nazwisko ".$n." Wzrost: ".$p[1]." jest wysoki waga:".$w;
            } else {
                echo "Nazwisko ".$n." wzrost: ".$p[1]." jest niski waga:".$w;
            }
        }
    fclose($plik);


    ?>
</body>
</html>