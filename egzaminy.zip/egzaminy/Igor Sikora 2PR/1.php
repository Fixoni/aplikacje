<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="" method="POST">
        <h2>Sklep</h2>
        <label>Wybierz towar</label>
        <select name="zakupy" id="zakupy" multiple>
            <option value="maslo">Masło</option>
            <option value="bulka">Bułka</option>
            <option value="ziemniaki">Ziemniaki</option>
            <option value="ryba">Ryba</option>
            <option value="szynka">Szynka</option>
            <option value="pomidor">Pomidor</option>
        </select> 
        <br>
        <label for="">Podaj ilosc</label>
        <br>
        <input type="number" name="ilosc">
        <br>
        <label for="">Sposób zakupów</label>
        <input type="radio" name="wykonanie">Samodzielnie
        <input type="radio" name="wykonanie">Osoba 3
        <br>
        <button type="submit">Wyślij</button>
    </form>
    <?php
    $zakupy=$_POST["zakupy"];
    $ilosc=$_POST["ilosc"];
    $sposob=$_POST["wykonanie"];
    if($sposob=="Samodzielnie") {
        echo "Przedmioty: ".$zakupy." ilość: ".$ilosc." kto robi zakupy: samodzielnie";
    } else {
        echo "Przedmioty: ".$zakupy." ilość: ".$ilosc." kto robi zakupy: osoba 3";
    }
    //nazwa 
    //ilosc sztuk 
    //sposob 
    ?>
</body>
</html>